import java.util.*;

public class Player
{
    private Room currentRoom;
    private Item noItem = new Item("noItem", false);
    public Room previousRoom = null;
    private Examine examine;
    private ArrayList inventory;
    public Item equippedItem = noItem;
    private Item combine1;
    private Item combine2;
    public int partOfGame = 1;
    private boolean beenToPlaza;
    public boolean backpack;
    
    private int cutscene = 1;
    
    private boolean takeRuby;
    private boolean takeSapphire;
    private boolean takeJournal;
    private boolean takeTape;
    private boolean takeFarmKey;
    private boolean takeSuperGlue;
    private boolean takeSkeletonKey;
    private boolean tookEmerald;
    
    private boolean walkBoolean;

    /**
     * Constructor for objects of class Player
     */
    public Player()
    {
        currentRoom = null;
        examine = new Examine();
        inventory = new ArrayList();
    }
    
    public void changeExamine()
    {
        examine.alterExamine(examine.getPassword());
    }
    
    public void resetPassword()
    {
        examine.resetPassword();
    }
    
    public int getCutscene()
    {
        return cutscene;
    }
    
    public String getEquipString()
    {
        return equippedItem.toString();
    }
    
    public void setCutscene(int x)
    {
        cutscene = x;
    }

    public Room getCurrentRoom()
    {
        return currentRoom;
    }
    
    public void setCurrentRoom(Room x)
    {
        currentRoom = x;
    }
    
    public int getPassword()
    {
        return examine.getPassword();
    }
    
    public Item getEquip()
    {
        return equippedItem;
    }
    
    public String walk(String direction, Room rileyRoom, Room cameronRoom)
    {
        String resultString = "";
        walkBoolean = false;
        Room nextRoom;
        nextRoom = null;
        String rileysRoom = rileyRoom.getName();
        String cameronsRoom = cameronRoom.getName();
        if(direction.equals("back")){
            if(previousRoom == null){
                resultString += "You haven't gone anywhere yet!";
                return resultString;
            }
            else{
                if(partOfGame == 2){
                    resultString += "The boy calls after you. \"Hey! Where you think you're going?\"";
                    return resultString;
                }
                else if(partOfGame == 3){
                    if(currentRoom.getName().equals("mainGate2") || currentRoom.getName().equals("mainGate1")){
                        resultString += "Cameron calls after you. \"Hey! Where you think you're going?\"";
                        return resultString;
                    }
                    else if(currentRoom.getName().equals("road")){
                       resultString += "Cameron calls after you. \"We should take this road east first!\"";
                       return resultString; 
                    }
                }
                nextRoom = previousRoom;
                previousRoom = currentRoom;
                currentRoom = nextRoom;
                resultString += getCurrentRoom().getLongDescription(rileysRoom, cameronsRoom);
                currentRoom.getExit(direction);
                walkBoolean = true;
                return resultString;
            }
        }
        else{
            if(partOfGame == 2){
                resultString += "\"Hey, what do you think you're doing?\" the boy says." +
                "\n" +          "\"Just check your tablet.\"";
                return resultString;
            }
            else if((currentRoom.getName().equals("road") && !direction.equals("east")) && partOfGame == 3){
                resultString += "Cameron calls after you. \"We should take this road east first!\"";
                return resultString; 
            }
            previousRoom = currentRoom;
            nextRoom = currentRoom.getExit(direction);
            if (nextRoom == null){
                resultString += "There's nothing of interest in that direction.";
                return resultString;
            }
            else{
                if(nextRoom.barredRoom() == true){
                    resultString += nextRoom.getLockDescription();
                    return resultString;
                }
                if(currentRoom.getName().equals("mainGate1") && direction.equals("south")){
                    resultString += "There's nothing of interest in that direction.";
                    return resultString;
                }
                currentRoom = nextRoom;
                if(currentRoom.getName().equals("plaza") && beenToPlaza == false){
                    beenToPlaza = true;
                    cutscene = 5;
                    partOfGame = 4;
                    walkBoolean = true;
                }
                else{
                    if(partOfGame == 1){
                        cutscene = 2;
                        partOfGame = 2;
                    }
                    else if(partOfGame == 4){
                        resultString += getCurrentRoom().getLongDescription(rileysRoom, cameronsRoom);
                        partOfGame = 5;
                    }
                    else{
                        resultString += getCurrentRoom().getLongDescription(rileysRoom, cameronsRoom);
                    }
                    walkBoolean = true;
                }
                return resultString;
            }
        }   
    }
    
    public boolean getWalkBoolean()
    {
        return walkBoolean;
    }
    
    public String take(Command command)
    {
        String resultString = "";
        if(partOfGame == 2)
        {
            resultString += "The boy shifts impatiently. \"C'mon, just check your tablet already.\"";
            return resultString;
        }
        if(!command.hasSecondWord())
        {
            resultString += "Take what?";
            return resultString;
        }
        else
        {
            if(backpack == false && inventory.size() > 4)
            {
                resultString += "You can't carry any more items.";
                return resultString;
            }
            ArrayList itemList = new ArrayList(currentRoom.getItems());
            String itemTaken = command.getSecondWord();
            if(itemTaken.equals("shiny_item"))
            {
                itemTaken = "emerald";
            }
            Item itemToTake = null;
            for(int x = 0; x < itemList.size(); x++)
            {
                itemToTake = (Item)itemList.get(x);
                if(itemToTake.toString().equals(itemTaken)){
                    if(itemTaken.equals("backpack") && partOfGame < 5)
                    {
                        resultString += "You take the backpack.";
                        currentRoom.getItems().remove(itemToTake);
                        backpack = true;
                        return resultString;
                    }
                    else if(itemTaken.equals("backpack")
                    ){
                        resultString += "You had your chance. Riley has the backpack now.";
                        return resultString;
                    }
                    else
                    {
                        if(itemToTake.getAvailability() == true)
                        {
                            resultString += "You can't take this item yet, cheater!";
                            return resultString;
                        }
                        else{
                            if(itemToTake.toString().equals("emerald") && tookEmerald == false)
                            {
                                Item scoopCheck;
                                for(int y = 0; y < inventory.size(); y++)
                                {
                                    scoopCheck = (Item)inventory.get(y);
                                    if(scoopCheck.toString().equals("scoopertron_2000"))
                                    {
                                        inventory.add(itemToTake);
                                        currentRoom.getItems().remove(itemToTake);
                                        inventory.remove(equippedItem);
                                        equippedItem = noItem;
                                        resultString += "You take the shiny item, which turns out to be an emerald.";
                                        tookEmerald = true;
                                        return resultString;
                                    }
                                }
                                resultString += "You can't reach the shiny_item without a tool.";
                                return resultString;
                            }
                            inventory.add(itemToTake);
                            currentRoom.getItems().remove(itemToTake);
                            ArrayList droppedItemsList = new ArrayList(currentRoom.getDroppedItems());
                            Item itemToRemove = null;
                            for(int z = 0; z < droppedItemsList.size(); z++)
                            {
                                itemToRemove = (Item)droppedItemsList.get(x);
                                if(itemToRemove.toString().equals(itemTaken))
                                {
                                    currentRoom.getDroppedItems().remove(itemToRemove);
                                }
                            }
                            resultString += "You take the " + command.getSecondWord() + ".";
                            return resultString;
                        }
                    }
                }
            }
        }
        resultString += "No such item exists in this area.";
        return resultString;
    }
    
    public String drop(Command command)
    {
        String resultString = "";
        if(partOfGame == 2)
        {
            resultString += "\"Quit fooling around and check your tablet,\" the boy grumbles.";
            return resultString;
        }
        if(!command.hasSecondWord()){
            resultString += "Drop what?";
            return resultString;
        }
        else{
            String itemDropped = command.getSecondWord();
            Item itemToDrop = null;
            for(int x = 0; x < inventory.size(); x++){
                itemToDrop = (Item)inventory.get(x);
                if(itemToDrop.toString().equals(itemDropped)){
                    currentRoom.getItems().add(itemToDrop);
                    currentRoom.getDroppedItems().add(itemToDrop);
                    inventory.remove(itemToDrop);
                    resultString += "You drop the " + command.getSecondWord() + ".";
                    return resultString;
                }
            }
        }
        resultString += "You don't have any such item.";
        return resultString;
    }
    
    public String checkInventory()
    {
        String inventoryString = "";
        if(partOfGame == 2)
        {
            inventoryString += "\n" + "The tall boy rolls his eyes. \"You even paying attention to me?\"";
            return inventoryString;
        }
        inventoryString = "\n" + "Your current items include:";
        if(inventory.size() == 0)
            inventoryString += "\n" + "     " + "Nothing. You haven't gathered any items yet.";
        else{
            for(int x = 0; x < inventory.size(); x++){
                Item itemToAdd = (Item)inventory.get(x);
                inventoryString += "\n" + "     " + itemToAdd.toString();
            }
        }
        return inventoryString;
    }
    
    public String equip(Command command)
    {
        String resultString = "";
        if(partOfGame == 2){
            resultString += "The boy looks at you judgementally. \"Hey man, are you slow or something?\"";
            return resultString;
        }
        String itemEquipped = command.getSecondWord();
        Item itemToEquip = null;
        for(int x = 0; x < inventory.size(); x++){
            itemToEquip = (Item)inventory.get(x);
            if(itemToEquip.toString().equals(itemEquipped)){
                equippedItem = itemToEquip;
                resultString += "You equip the " + command.getSecondWord() + ".";
                return resultString;
            }
        }
        resultString += "You have no such item to equip.";
        return resultString;
    }
    
    public String unequip(Command command)
    {
        String resultString = "";
        if(partOfGame == 2){
            resultString += "The boy looks at you judgementally. \"Hey man, are you slow or something?\"";
            return resultString;
        }
        else if(!equippedItem.toString().equals("noItem")){
            if(command.hasSecondWord() == true){
                String itemUnequipped = command.getSecondWord();
                Item itemToUnequip = equippedItem;
                if(itemToUnequip.toString().equals(itemUnequipped)){
                    equippedItem = noItem;
                    resultString += "You unequip the " + command.getSecondWord() + ".";
                    return resultString;
                }
                resultString += "You don't have this item equipped.";
                return resultString;
            }
            else{
                resultString += "You uneqip the " + equippedItem.toString() + ".";
                equippedItem = noItem;
                return resultString;
            }
        }
        resultString += "You don't have an item equipped.";
        return resultString;
    }
    
    public String combineItems(Command command)
    {
        String resultString = "";
        if(partOfGame == 2){
            resultString += "\"For pete's sake, just check the damn tablet,\" the boy grumbles.";
            return resultString;
        }
        if(combine1 == null){
            String itemCombined1 = command.getSecondWord();
            Item itemToCombine1 = null;
            for(int x = 0; x < inventory.size(); x++){
                itemToCombine1 = (Item)inventory.get(x);
                if(itemToCombine1.toString().equals(itemCombined1)){
                    combine1 = itemToCombine1;
                    resultString += "Combine the "+ command.getSecondWord() + " with...?";
                    return resultString;
                }
            }
            resultString += "You have no such item to combine.";
        }
        else{
            String itemCombined2 = command.getSecondWord();
            Item itemToCombine2 = null;
            for(int x = 0; x < inventory.size(); x++){
                itemToCombine2 = (Item)inventory.get(x);
                if(itemToCombine2.toString().equals(itemCombined2)){
                    combine2 = itemToCombine2;
                    if((combine1.toString().equals("beads") && combine2.toString().equals("string") && equippedItem.toString().equals("small_crucifix")) ||
                       (combine1.toString().equals("string") && combine2.toString().equals("beads") && equippedItem.toString().equals("small_crucifix")) ||
                       (combine1.toString().equals("beads") && combine2.toString().equals("small_crucifix") && equippedItem.toString().equals("string")) ||
                       (combine1.toString().equals("small_crucifix") && combine2.toString().equals("beads") && equippedItem.toString().equals("string")) ||
                       (combine1.toString().equals("small_crucifix") && combine2.toString().equals("string") && equippedItem.toString().equals("beads")) ||
                       (combine1.toString().equals("string") && combine2.toString().equals("small_crucifix") && equippedItem.toString().equals("beads"))){
                        inventory.remove(combine1);
                        inventory.remove(combine2);
                        inventory.remove(equippedItem);
                        equippedItem = noItem;
                        resultString += "You combine the small_crucifix, the beads, and the string to make" +
                                        "\n" + "a rosary.";
                        inventory.add(new Item("rosary", false));
                    }
                    else if((combine1.toString().equals("broom_handle") && combine2.toString().equals("rake_handle") && equippedItem.toString().equals("tape")) ||
                            (combine1.toString().equals("rake_handle") && combine2.toString().equals("broom_handle") && equippedItem.toString().equals("tape"))){
                        inventory.remove(combine1);
                        inventory.remove(combine2);
                        inventory.remove(equippedItem);
                        equippedItem = noItem;
                        resultString += "You use the tape to bind together the broom and rake handles, and" +
                                        "\n" + "obtain a long_stick.";
                        inventory.add(new Item("long_stick", false));
                    }
                    else if((combine1.toString().equals("long_stick") && combine2.toString().equals("ladle") && equippedItem.toString().equals("super_glue")) ||
                            (combine1.toString().equals("ladle") && combine2.toString().equals("long_stick") && equippedItem.toString().equals("super_glue"))){
                        inventory.remove(combine1);
                        inventory.remove(combine2);
                        inventory.remove(equippedItem);
                        equippedItem = noItem;
                        resultString += "You stick the ladle to the end of the long_stick with super_glue," +
                                        "\n" + "and obtain a scoopertron_2000.";
                        inventory.add(new Item("scoopertron_2000", false));
                    }
                    else{
                        resultString += "These two items don't work together.";
                    }
                    combine1 = null;
                    combine2 = null;
                    return resultString;
                }
            }
            resultString += "You have no such item to combine.";
        }
        return resultString;
    }
    
    public String tablet(String riley, String cameron)
    {
        String resultString = "";
        if(partOfGame == 1){
            resultString += "\n" +"You have no idea what this device is or what it's for." + 
                            "\n" + "Better to leave it alone for now.";
        }
        else if(partOfGame == 2){
            cutscene = 3;
            partOfGame = 3;
        }
        else{
            resultString += "Your tablet gives you the following information:" +
               "\n" + "     " + riley +
               "\n" + "     " + cameron;
        }
        return resultString;
    }
    
    public void examineStuff()
    {
        Room unlockRoom;
        if(currentRoom.getName().equals("mainGate1"))
        {
            unlockRoom = currentRoom.getExit("north");
            unlockRoom.unlockRoom();
            Room nextRoom = null;
            nextRoom = currentRoom.getExit("south");
            currentRoom = nextRoom;
            cutscene = 4;
        }
        else if(currentRoom.getName().equals("bedroom"))
        {
            takeJournal = true;
        }
    }
    
    public String examine(Command command)
    {
        String resultString = "";
        if(partOfGame == 2)
        {
            resultString += "The boy gives you a funny look. \"What're you lookin' around for?\"";
            return resultString;
        }
        if(command.hasSecondWord() == false)
        {
            resultString += "You need to choose something to examine.";
            return resultString;
        }
        String commandCheck = command.getSecondWord();
        if(commandCheck.equals("tablet") || commandCheck.equals("backpack"))
        {
            resultString += "You can't examine that.";
            return resultString;
        }
        else if(commandCheck.equals("Riley") || commandCheck.equals("riley") || commandCheck.equals("Cameron") || commandCheck.equals("cameron"))
        {
            resultString += "You can't examine people, whether they're nearby or not!";
            return resultString;
        }
        Item itemToExamine = null;
        String itemExamined = command.getSecondWord();
        for(int x = 0; x < inventory.size(); x++)
        {
            itemToExamine = (Item)inventory.get(x);
            if(itemToExamine.toString().equals(itemExamined))
            {
                examine.setEquip(equippedItem.toString());
                resultString += examine.examineItem(itemExamined);
                if(examine.getAction() == true)
                {
                    if(itemExamined.equals("bread"))
                    {
                        inventory.add(new Item("gold_key", false));
                        inventory.remove(equippedItem);
                        equippedItem = noItem;
                        inventory.remove(itemToExamine);
                    }
                    else if(itemExamined.equals("broom"))
                    {
                        inventory.add(new Item("broom_handle", false));
                        inventory.remove(itemToExamine);
                    }
                    else if(itemExamined.equals("rake"))
                    {
                        inventory.add(new Item("rake_handle", false));
                        inventory.remove(itemToExamine);
                    }
                }
                return resultString;
            }
        }
        
        Object objectToExamine = null;
        String objectExamined = command.getSecondWord();
        ArrayList objectList = new ArrayList(currentRoom.getObjects());
        for(int y = 0; y < objectList.size(); y++)
        {
            objectToExamine = (Object)objectList.get(y);
            if(objectToExamine.toString().equals(objectExamined))
            {
                examine.setEquip(equippedItem.toString());
                resultString += examine.examineObject(objectExamined);
                if(examine.getAction() == true)
                {
                    Room unlockRoom;
                    if(objectExamined.equals("plaque"))
                    {
                        if(equippedItem.toString().equals("sapphire"))
                        {
                            inventory.remove(equippedItem);
                            equippedItem = noItem;
                        }
                        else if(equippedItem.toString().equals("ruby"))
                        {
                            inventory.remove(equippedItem);
                            equippedItem = noItem;
                        }
                        else if(equippedItem.toString().equals("emerald"))
                        {
                            inventory.remove(equippedItem);
                            equippedItem = noItem;
                        }
                        if(examine.getOpenCastle() == true)
                        {
                            unlockRoom = currentRoom.getExit("north");
                            unlockRoom.unlockRoom();
                        }
                    }
                    else if(objectExamined.equals("display"))
                    {
                        inventory.remove(equippedItem);
                        equippedItem = noItem;
                        takeRuby = true;
                    }
                    else if(objectExamined.equals("bramble_bush"))
                    {
                        inventory.remove(equippedItem);
                        equippedItem = noItem;
                        takeTape = true;
                    }
                    else if(objectExamined.equals("vase"))
                    {
                        inventory.remove(equippedItem);
                        equippedItem = noItem;
                    }
                    else if(objectExamined.equals("corpse") || objectExamined.equals("dummy"))
                    {
                        inventory.remove(equippedItem);
                        equippedItem = noItem;
                        takeSuperGlue = true;
                    }
                    else if(objectExamined.equals("lock"))
                    {
                        inventory.remove(equippedItem);
                        equippedItem = noItem;
                        unlockRoom = currentRoom.getExit("north");
                        unlockRoom.unlockRoom();
                    }
                    else if(objectExamined.equals("fourth_haystack"))
                    {
                        takeFarmKey = true;
                    }
                    else if(objectExamined.equals("chest"))
                    {
                        inventory.remove(equippedItem);
                        equippedItem = noItem;
                        takeSapphire = true;
                    }
                    else if(objectExamined.equals("door"))
                    {
                        inventory.remove(equippedItem);
                        equippedItem = noItem;
                        cutscene = 6;
                    }
                    else if(objectExamined.equals("dirt_mound"))
                    {
                        inventory.remove(equippedItem);
                        equippedItem = noItem;
                        takeSkeletonKey = true;
                    }
                }
                return resultString;
            }
        }
        resultString += "There's no such thing for you to examine.";
        return resultString;
    }
    
    public boolean getItemStatus(String item){
        if(item.equals("sapphire")){
            return takeSapphire;
        }
        else if(item.equals("ruby")){
            return takeRuby;
        }
        else if(item.equals("journal")){
            return takeJournal;
        }
        else if(item.equals("tape")){
            return takeTape;
        }
        else if(item.equals("farm_key")){
            return takeFarmKey;
        }
        else if(item.equals("super_glue")){
            return takeSuperGlue;
        }
        else if(item.equals("skeleton_key")){
            return takeSkeletonKey;
        }
        return false;
    }
}
