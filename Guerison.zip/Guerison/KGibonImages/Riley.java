import java.util.*;

/**
 * Write a description of class Characters here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Riley
{
    private Room currentRoom;
    private ArrayList inventory;
    private int timesWalked = 0;
    private Room previousRoom = null;
    
    public Riley()
    {
        currentRoom = null;
        inventory = new ArrayList();
    }
    
    public Room getCurrentRoom()
    {
        return currentRoom;
    }
    
    public void setCurrentRoom(Room x)
    {
        currentRoom = x;
    }
   
    public String getTabletInfo()
    {
        String resultString = "Riley is currently " + currentRoom.getDescription() + ".";
        if (inventory.size() != 0)
        {
            resultString += "\n" + "Her items are: ";
            Iterator iter = inventory.iterator();
            while(iter.hasNext())
            {
                Item nextItem = (Item) iter.next();
                resultString += "\n" + "\t" + nextItem.toString();
            }
        }
        return resultString;
    }
    
    public void walk()
    {
        Room nextRoom;
        nextRoom = null;
        if(timesWalked == 0){
            timesWalked ++;
            previousRoom = currentRoom;
            return;
        }
        else if(timesWalked == 1){
            timesWalked ++;
            previousRoom = currentRoom;
            nextRoom = currentRoom.getExit("north");
            currentRoom = nextRoom;
            return;
        }
        else if(timesWalked == 2){
            timesWalked ++;
            previousRoom = currentRoom;
            nextRoom = currentRoom.getExit("east");
            currentRoom = nextRoom;
            return;
        }
        timesWalked++;
        String direction = null;
        boolean ready = false;
        int x;
        while(ready == false){
            x = 1 + (int)(Math.random() * 4);
            switch(x){
                case 1:
                    direction = "north";
                    break;
                case 2:
                    direction = "east";
                    break;
                case 3:
                    direction = "south";
                    break;
                case 4:
                    direction = "west";
                    break;
                default:
                    direction = "north";
            }
            nextRoom = currentRoom.getExit(direction);
            if(nextRoom != null && nextRoom.barredRoom() != true){
                ready = true;
                if(timesWalked == 3){
                    timesWalked = 4;
                }
            }
        }
        previousRoom = currentRoom;
        currentRoom = nextRoom;
    }
    
    public void goBack()
    {
        timesWalked --;
        Room nextRoom = null;
        nextRoom = previousRoom;
        previousRoom = currentRoom;
        currentRoom = nextRoom;
    }
}