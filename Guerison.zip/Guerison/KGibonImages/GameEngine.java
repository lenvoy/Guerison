import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

/**
 *  This is the main class of the Guerison game code.
 *  It handles most of the printings and creates the rooms,
 *  as well as calling methods based on the commands given by the user.
 * 
 * 
 * @author  Kevin Gibson
 * @version 3.0 (February 2012)
 */

class GameEngine
{
    private UserInterface gui;
    private Parser parser;
    public Player player;
    private Riley riley;
    private boolean rileyTalked;
    private Cameron cameron;
    private boolean cameronTalked;
    private Cutscenes cutscenes;
    private ArrayList cItems;
    public ArrayList printList;
    
    /**
     * Create the game and initialise its internal map.
     */
    public GameEngine() 
    {
        cutscenes = new Cutscenes();
        player = new Player();
        riley = new Riley();
        cameron = new Cameron();
        createRooms();
        parser = new Parser();
    }
    
    public void setGUI(UserInterface userInterface)
    {
        gui = userInterface;
        printWelcome();
    }

    /**
     * Create all the rooms and link their exits together.
     */
    private void createRooms()
    {
        Room field, mainGate1, mainGate2, road, library, church, 
        graveyard, plaza, castleEntrance, castle1, castle2, courtyard, 
        residentialSector, mansion, bedroom, kitchen, garden, 
        smallHouse, mediumHouse, watchTower, university,infirmary, 
        ranch, farmHouse;
      
        // creates the rooms
        field = new Room("in the field", "field");
        mainGate1 = new Room("at the main gate of the citadel", "mainGate1");
        mainGate2 = new Room("at the main gate of the citadel", "mainGate2");
        road = new Room("on the road just past the main gate", "road");
        library = new Room("in the town library", "library");
        church = new Room("in the church", "church");
        graveyard = new Room("in the graveyard", "graveyard");
        plaza = new Room("at the plaza", "plaza");
        castleEntrance = new Room("at the castle entrance", "castleEntrance");
        castle1 = new Room("on the first floor of the castle", "castle1");
        castle2 = new Room("on the first floor of the castle", "castle2");
        courtyard = new Room("in the courtyard", "courtyard");
        residentialSector = new Room("at the entrance of the residential sector",
            "residentialSector");
        mansion = new Room("in the mansion's main hall", "mansion");
        kitchen = new Room("in the mansion's kitchen", "kitchen");
        bedroom = new Room("in the mansion's bedroom", "bedroom");
        garden = new Room("in the mansion's garden", "garden");
        smallHouse = new Room("in the small house", "smallHouse");
        mediumHouse = new Room("in the medium sized house", "mediumHouse");
        watchTower = new Room("inside the watch tower", "watchTower");
        university = new Room("at the university", "university");
        infirmary = new Room("in the university's infirmary", "infirmary");
        ranch = new Room("at the ranch", "ranch");
        farmHouse = new Room("in the farm house", "farmHouse");
        
        field.setExit("north", mainGate1);
        
        mainGate1.setExit("north", road);
        mainGate1.setExit("south", mainGate2);
            mainGate1.addItem(new Item("paper", false));
                mainGate1.addObject(new Object("gate"));
                mainGate1.addObject(new Object("wall"));
                mainGate1.addObject(new Object("monitor"));
                mainGate1.addObject(new Object("bar"));
                
        mainGate2.setExit("north", road);
                mainGate2.addObject(new Object("gate"));
                mainGate2.addObject(new Object("wall"));
                mainGate2.addObject(new Object("monitor"));
                mainGate2.addObject(new Object("bar"));
            
        road.setExit("north", church);
        road.setExit("east", plaza);
        road.setExit("south", mainGate2);
        road.setExit("west", library);
            road.addItem(new Item("letter", false));
                road.addObject(new Object("street_lights"));
                road.addObject(new Object("mailbox"));
                road.addObject(new Object("sign"));
                road.addObject(new Object("road"));
        
        library.setExit("north", graveyard);
        library.setExit("east", road);
            library.addItem(new Item("town_history", false));
            library.addItem(new Item("napoleon_biography", false));
            library.addItem(new Item("the_telling_pool", false));
                library.addObject(new Object("shelf"));
                library.addObject(new Object("reception_desk"));
        
        church.setExit("south", road);
        church.setExit("west", graveyard);
            church.addItem(new Item("bible", false));
            church.addItem(new Item("small_crucifix", false));
            church.addItem(new Item("ruby", true));
                church.addObject(new Object("altar"));
                church.addObject(new Object("pews"));
                church.addObject(new Object("display"));
        
        graveyard.setExit("east", church);
        graveyard.setExit("south", library);
            graveyard.addItem(new Item("bouquet", false));
                graveyard.addObject(new Object("grave"));
                
        
        plaza.setExit("north", castleEntrance);
        plaza.setExit("east", university);
        plaza.setExit("south", residentialSector);
        plaza.setExit("west", road);
            plaza.addItem(new Item("backpack", false));
            plaza.addItem(new Item("coin", false));
                plaza.addObject(new Object("fountain"));
                plaza.addObject(new Object("street_lights"));
        
        castleEntrance.setExit("north", castle1);
        castleEntrance.setExit("south", plaza);
            castleEntrance.addItem(new Item("emerald", true));
                castleEntrance.addObject(new Object("castle_gate"));
                castleEntrance.addObject(new Object("drawbridge"));
                castleEntrance.addObject(new Object("plaque"));
                castleEntrance.addObject(new Object("moat"));
        
        castle1.setExit("north", castle2);
        castle1.setExit("south", castleEntrance);
        castle1.setExit("west", courtyard);
                castle1.addObject(new Object("tapestry"));
                castle1.addObject(new Object("door"));
                castle1.addObject(new Object("chandelier"));
         
        courtyard.setExit("east", castle1);
            courtyard.addItem(new Item("shovel", false));
            courtyard.addItem(new Item("skeleton_key", true));
                courtyard.addObject(new Object("dirt_mound"));
                courtyard.addObject(new Object("gargoyle"));
                courtyard.addObject(new Object("hedge"));
            
        castle2.setExit("north", castle1);
        
        residentialSector.setExit("north", plaza);
        residentialSector.setExit("east", smallHouse);
        residentialSector.setExit("south", mediumHouse);
        residentialSector.setExit("west", mansion);
                residentialSector.addObject(new Object("street_lights"));
        
        mansion.setExit("east", residentialSector);
        mansion.setExit("south", bedroom);
        mansion.setExit("west", kitchen);
            mansion.addItem(new Item("beads", false));
                mansion.addObject(new Object("portrait"));
                mansion.addObject(new Object("table"));
        
        kitchen.setExit("east", mansion);
        kitchen.setExit("west", garden);
            kitchen.addItem(new Item("bread_knife", false));
            kitchen.addItem(new Item("bread", false)); 
                kitchen.addObject(new Object("oven"));
                kitchen.addObject(new Object("pantry"));
        
        bedroom.setExit("north", mansion);
            bedroom.addItem(new Item("journal", true));
                bedroom.addObject(new Object("canopy_bed"));
                bedroom.addObject(new Object("vanity"));
                bedroom.addObject(new Object("safe"));
            
        garden.setExit("east", kitchen);
            garden.addItem(new Item("tape", true));
                garden.addObject(new Object("bramble_bush"));
                garden.addObject(new Object("fence"));
        
        smallHouse.setExit("north", university);
        smallHouse.setExit("south", watchTower);
        smallHouse.setExit("west", residentialSector);
            smallHouse.addItem(new Item("scalpel", false));
            smallHouse.addItem(new Item("string", false));
        
        mediumHouse.setExit("north", residentialSector);
            mediumHouse.addItem(new Item("ladle", false));
                mediumHouse.addObject(new Object("vase"));
        
        watchTower.setExit("north", smallHouse);
                watchTower.addObject(new Object("wooden_staircase"));
            
        university.setExit("north", ranch);
        university.setExit("east", infirmary);
        university.setExit("south", smallHouse);
        university.setExit("west", plaza);
            university.addItem(new Item("broom", false));
                university.addObject(new Object("doors"));
        
        infirmary.setExit("west", university);
            infirmary.addItem(new Item("super_glue", true));
                infirmary.addObject(new Object("corpse"));
                infirmary.addObject(new Object("dummy"));
        
        ranch.setExit("north", farmHouse);
        ranch.setExit("south", university);
            ranch.addItem(new Item("farm_key", true));
            ranch.addItem(new Item("rake", false));
                ranch.addObject(new Object("hay"));
                ranch.addObject(new Object("fourth_haystack"));
                ranch.addObject(new Object("fence"));
                ranch.addObject(new Object("lock"));
        
        farmHouse.setExit("south", ranch);
            farmHouse.addItem(new Item("shears", false));
            farmHouse.addItem(new Item("sapphire", true));
                farmHouse.addObject(new Object("chest"));
            
        player.setCurrentRoom(field);
        riley.setCurrentRoom(mainGate2);
        cameron.setCurrentRoom(mainGate2);
    }

    /**
     * Print out the opening message for the player.
     */
    private void printWelcome()
    {
        gui.showImage("Guerison.png");
        printCutscenes();
    }

    private boolean ruby1;
    private boolean sapphire1;
    private boolean emerald1;
    private boolean journal1;
    private boolean tape1;
    private boolean farmKey1;
    private boolean superGlue1;
    private boolean skeletonKey1;
    
    public boolean useEnter;
    private boolean usePassword;
    private int printLength = 0;
    
    private boolean doneTalking;
    private boolean finalPassword;
    
    /**
     * Given a command, process (that is: execute) the command.
     * If this command ends the game, true is returned, otherwise false is
     * returned.
     */
    public void interpretCommand(String commandLine) 
    {
        if(doneTalking == true)
        {
            doneTalking = false;
            gui.showImage("Tablet.png");
        }
        else if(finalPassword == true)
        {
            gui.print(parser.enterPassword(3, commandLine));
            if(parser.getCorrect(3) == true)
            {
                player.resetPassword();
                player.setCutscene(9);
                printCutscenes();
                finalPassword = false;
                return;
            }
            else if(parser.getCorrect(3) == false && parser.getEndGame() == true)
            {
                player.resetPassword();
                player.setCutscene(10);
                printCutscenes();
                finalPassword = false;
                return;
            }
        }
        
        if(useEnter == true)
        {
            gui.println("");
            switch(player.getCutscene())
            {
                case 1:
                if(printLength == 0){
                    gui.showImage("Intro.png");
                }
                break;
                case 2:
                if(printLength == 4){
                    gui.showImage("GoNorth2.png");
                }
                break;
                case 3:
                switch(printLength)
                {
                    case 1:
                    gui.showImage("TabletC.png");
                    break;
                    case 2:
                    gui.showImage("TabletRC.png");
                    break;
                    case 5:
                    gui.showImage("GoNorth3.png");
                    break;
                    case 8:
                    gui.showImage("Tablet.png");
                    break;
                    case 10:
                    gui.showImage("TabletR.png");
                    break;
                    case 11:
                    gui.showImage("TabletRC.png");
                    break;
                    case 13:
                    gui.showImage("Tablet.png");
                    break;
                }
                break;
                case 4:
                switch(printLength)
                {
                    case 1:
                    gui.showImage("TabletR.png");
                    break;
                    case 2:
                    gui.showImage("Tablet.png");
                    break;
                    case 4:
                    gui.showImage("TabletC.png");
                    break;
                    case 5:
                    gui.showImage("Tablet.png");
                    break;
                }
                break;
                case 5:
                switch(printLength)
                {
                    case 2:
                    gui.showImage("TabletR.png");
                    break;
                    case 3:
                    gui.showImage("TabletRC.png");
                    break;
                    case 6:
                    gui.showImage("TabletR.png");
                    break;
                    case 9:
                    gui.showImage("Tablet.png");
                }
                break;
                case 6:
                switch(printLength)
                {
                    case 1:
                    gui.showImage("TabletC.png");
                    break;
                    case 2:
                    gui.showImage("TabletRC.png");
                    break;
                    case 5:
                    gui.showImage("Tablet.png");
                    break;
                    case 6:
                    gui.showImage("TabletC.png");
                    break;
                    case 7:
                    gui.showImage("TabletRC.png");
                    break;
                    case 10:
                    gui.showImage("Tablet.png");
                    break;
                    case 11:
                    gui.showImage("TabletR.png");
                    break;
                    case 12:
                    gui.showImage("Tablet.png");
                    break;
                }
                break;
                case 9:
                switch(printLength)
                {
                    case 1:
                    gui.showImage("End.png");
                    break;
                    case 2:
                    gui.showImage("EndC.png");
                    break;
                    case 3:
                    gui.showImage("EndRC.png");
                }
                break;
            }
            gui.print((String)printList.get(printLength));
            if(printLength == printList.size() - 1)
            {
                if(player.getCutscene() == 6)
                {
                    printLength = 0;
                    gui.println("\n");
                    gui.print("> ");
                    finalPassword = true;
                    return;
                }
                if(player.getCutscene() == 7 || player.getCutscene() == 8)
                {
                    doneTalking = true;
                }
                else if(player.getCutscene() > 8)
                {
                    endGame();
                    return;
                }
                player.setCutscene(0);
                useEnter = false;
                printLength = 0;
                gui.println("\n");
                gui.print("> ");
                return;
            }
            printLength++;
            return;
        }
        
        gui.println(commandLine);
        Command command = parser.getCommand(commandLine);
        String commandWord = command.getCommandWord();
        
        if(player.getPassword() > 0)
        {
            gui.print(parser.enterPassword(player.getPassword(), commandLine));
            if(parser.getCorrect(1) == true)
            {
                player.examineStuff();
                player.changeExamine();
                player.resetPassword();
                printCutscenes();
                return;
            }
            else if(parser.getCorrect(2) == true)
            {
                player.examineStuff();
                player.changeExamine();
                player.resetPassword();
            }
            else if(parser.getCorrect(3) == true)
            {
                player.resetPassword();
                player.setCutscene(9);
                printCutscenes();
                return;
            }
            else if(parser.getCorrect(3) == false && parser.getEndGame() == true)
            {
                player.resetPassword();
                player.setCutscene(10);
                printCutscenes();
                return;
            }
            player.resetPassword();
            gui.println("\n");
            gui.print("> ");
            return;
        }

        if(command.isUnknown()) {
            gui.print("Please enter a valid command.");
            gui.println("\n");
            gui.print("> ");
            return;
        }
        
        if (commandWord.equals("help"))
            printHelp();
        else if (commandWord.equals("go")){
            if(!command.hasSecondWord())
                gui.println("Go where?");
            else {
                riley.walk();
                cameron.walk();
                String direction = command.getSecondWord();
                String walkString = player.walk(direction, riley.getCurrentRoom(),
                    cameron.getCurrentRoom());
                gui.println(walkString);
                if(player.getWalkBoolean() == false){
                    riley.goBack();
                    cameron.goBack();
                }
                else{
                    rileyTalked = false;
                    cameronTalked = false;
                    if(player.partOfGame == 4){
                        do {
                            cameron.walk();
                            cameron.walk();
                        } while (cameron.getCurrentRoom().toString().equals("plaza"));
                    }
                }
                if(player.getCurrentRoom().toString().equals("castle2")){
                    cutscenes.secondFloor();
                    endGame();
                }
            }
        }
        else if (commandWord.equals("quit"))
            quit(command);
        else if (commandWord.equals("look"))
        {
            if(player.partOfGame == 2){
                gui.println("The boy gives you a funny look. \"What're you lookin' around for?\"");
            }
            else{
                gui.println(player.getCurrentRoom().look(player.getCurrentRoom().getName(),
                riley.getCurrentRoom().getName(), cameron.getCurrentRoom().getName()));
            }
        }
        else if (commandWord.equals("take")){
            gui.println(player.take(command));
        }
        else if (commandWord.equals("drop")){
            gui.println(player.drop(command));
        }
        else if (commandWord.equals("equip")){
            if(!command.hasSecondWord()){
                gui.println("Equip what?");
            }
            else{
                gui.println(player.equip(command));
            }
        }
        else if(commandWord.equals("unequip")){
            gui.println(player.unequip(command));
        }
        else if (commandWord.equals("inventory")){
            gui.println(player.checkInventory());
        }
        else if (commandWord.equals("combine"))
            gui.println(player.combineItems(command));
        else if(commandWord.equals("tablet"))
            gui.println(player.tablet(riley.getTabletInfo(), cameron.getTabletInfo()));
        else if (commandWord.equals("examine")){
            gui.println(player.examine(command));
        }
        else if (commandWord.equals("talk"))
        {
            if(player.partOfGame < 4){
                gui.println("You'll have plenty of time later to talk to your opponents.");
            }
            else{
                if(command.hasSecondWord() == false){
                    gui.println("Talk to whom?");
                }
                else if(command.getSecondWord().equals("riley") ||
                        command.getSecondWord().equals("Riley")){
                    gui.showImage("TabletR.png");
                    if(rileyTalked == false){
                        player.setCutscene(7);
                        rileyTalked = true;
                    }
                    else{
                        gui.println("You've already talked to Riley here.");
                        gui.println("You can talk to her again if you see her later.");
                        doneTalking = true;
                    }
                }
                else if(command.getSecondWord().equals("cameron") ||
                        command.getSecondWord().equals("Cameron")){
                    gui.showImage("TabletC.png");
                    if(cameronTalked == false){
                        player.setCutscene(8);
                        cameronTalked = true;
                    }
                    else{
                        gui.println("You've already talked to Cameron here.");
                        gui.println("You can talk to him again if you see him later.");
                        doneTalking = true;
                    }
                }
                else{
                    gui.println("Whatever that is, you can't talk to it.");
                }
            }
        }
        
        printCutscenes();
        
        if(useEnter == false)
        {
            gui.println("");
            gui.print("> ");
            itemStuff();
        }
    }
    
    public void printCutscenes()
    {
        switch(player.getCutscene())
        {
            case 1:
            printList = new ArrayList(cutscenes.intro());
            break;
            case 2:
            printList = new ArrayList(cutscenes.mainGate1());
            gui.showImage("GoNorth.png");
            gui.print((String)printList.get(printLength));
            printLength ++;
            break;
            case 3:
            printList = new ArrayList(cutscenes.tablet());
            gui.showImage("Tablet.png");
            gui.print((String)printList.get(printLength));
            printLength ++;
            break;
            case 4:
            printList = new ArrayList(cutscenes.unlockGate());
            break;
            case 5:
            printList = new ArrayList(cutscenes.plaza());
            gui.print((String)printList.get(printLength));
            printLength ++;
            break;
            case 6:
            printList = new ArrayList(cutscenes.secondFloor());
            gui.print((String)printList.get(printLength));
            printLength ++;
            break;
            case 7:
            printList = new ArrayList(cutscenes.talkRiley());
            gui.showImage("TabletR.png");
            gui.print((String)printList.get(printLength));
            printLength ++;
            break;
            case 8:
            printList = new ArrayList(cutscenes.talkCameron());
            gui.showImage("TabletC.png");
            gui.print((String)printList.get(printLength));
            printLength ++;
            break;
            case 9:
            printList = new ArrayList(cutscenes.goodEnd());
            gui.showImage("Tablet.png");
            gui.print((String)printList.get(printLength));
            printLength ++;
            break;
            case 10:
            printList = new ArrayList(cutscenes.badEnd());
            gui.showImage("Tablet.png");
            gui.print((String)printList.get(printLength));
            printLength ++;
            break;
            default:
            useEnter = false;
            return;
        }
        useEnter = true;
    }

    /**
     * Print out some help information.
     * Here we print some stupid, cryptic message and a list of the 
     * command words.
     */
    private void printHelp() 
    {
        gui.println("Your command words are:");
        gui.println(parser.showCommands());
    }
    
    /** 
     * "Quit" was entered. Check the rest of the command to see
     * whether we really quit the game. Return true, if this command
     * quits the game, false otherwise.
     */
    private void quit(Command command) 
    {
        if(command.hasSecondWord())
        {
            gui.println("If you wish to exit the game, only enter 'quit'.");
        }
        else
            endGame();  // signal that we want to quit
    }
    
    private void endGame()
    {
        gui.enable(false);
    }
    
    private void itemStuff()
    {
        if(player.backpack == true && player.partOfGame == 5)
        {
            player.partOfGame = 6;
        }
        cItems = player.getCurrentRoom().getItems();
        if((player.getItemStatus("ruby") == true) && (ruby1 == false)){
            Item itemx;
            Item ruby;
            for(int x = 0; x < cItems.size(); x++){
                itemx = (Item)cItems.get(x);
                if(itemx.toString().equals("ruby")){
                    ruby = itemx;
                    ruby1 = true;
                    ruby.changeAvailability();
                }
            }
        }
        if(player.getItemStatus("sapphire") == true && sapphire1 == false){
            Item itemx;
            Item sapphire;
            for(int x = 0; x < cItems.size(); x++){
                itemx = (Item)cItems.get(x);
                if(itemx.toString().equals("sapphire")){
                    sapphire = itemx;
                    sapphire1 = true;
                    sapphire.changeAvailability();
                }
            }
        }
        if(player.getEquipString().equals("scoopertron_2000")){
            Item itemx;
            Item emerald;
            for(int x = 0; x < cItems.size(); x++){
                itemx = (Item)cItems.get(x);
                if(itemx.toString().equals("emerald")){
                    emerald = itemx;
                    emerald.changeAvailability();
                }
            }
        }
        else{
            Item itemx;
            Item emerald;
            for(int x = 0; x < cItems.size(); x++){
                itemx = (Item)cItems.get(x);
                if(itemx.toString().equals("emerald")){
                    emerald = itemx;
                    emerald.notAnymore();
                }
            }
        }
        if(player.getItemStatus("journal") == true && journal1 == false){
            Item itemx;
            Item journal;
            for(int x = 0; x < cItems.size(); x++){
                itemx = (Item)cItems.get(x);
                if(itemx.toString().equals("journal")){
                    journal = itemx;
                    journal1 = true;
                    journal.changeAvailability();
                }
            }
        }
        if(player.getItemStatus("tape") == true && tape1 == false){
            Item itemx;
            Item tape;
            for(int x = 0; x < cItems.size(); x++){
                itemx = (Item)cItems.get(x);
                if(itemx.toString().equals("tape")){
                    tape = itemx;
                    tape1 = true;
                    tape.changeAvailability();
                }
            }
        }
        if(player.getItemStatus("farm_key") == true && farmKey1 == false){
            Item itemx;
            Item farm_key;
            for(int x = 0; x < cItems.size(); x++){
                itemx = (Item)cItems.get(x);
                if(itemx.toString().equals("farm_key")){
                    farm_key = itemx;
                    farmKey1 = true;
                    farm_key.changeAvailability();
                }
            }
        }
        if(player.getItemStatus("super_glue") == true && superGlue1 == false){
            Item itemx;
            Item super_glue;
            for(int x = 0; x < cItems.size(); x++){
                itemx = (Item)cItems.get(x);
                if(itemx.toString().equals("super_glue")){
                    super_glue = itemx;
                    superGlue1 = true;
                    super_glue.changeAvailability();
                }
            }
        }
        if(player.getItemStatus("skeleton_key") == true && skeletonKey1 == false){
            Item itemx;
            Item skeleton_key;
            for(int x = 0; x < cItems.size(); x++){
                itemx = (Item)cItems.get(x);
                if(itemx.toString().equals("skeleton_key")){
                    skeleton_key = itemx;
                    skeletonKey1 = true;
                    skeleton_key.changeAvailability();
                }
            }
        }
    }
}
