
/**
 * Sets the items of the game.
 */
public class Item
{
    String x;
    public boolean unavailable = true;

    public Item(String description, boolean availability)
    {
        this.x = description;
        this.unavailable = availability;
    }

    public String toString()
    {
        return x;
    }
    
    public void changeAvailability()
    {
        unavailable = false;
    }
    
    public void notAnymore()
    {
        unavailable = true;
    }
    
    public boolean getAvailability()
    {
        return unavailable;
    }
}
