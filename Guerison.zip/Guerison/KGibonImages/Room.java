import java.util.*;

class Room 
{
    private String description;
    private String name;
    private HashMap exits;
    private ArrayList items;
    private ArrayList objects;
    private ArrayList droppedItems;
    private boolean unlocked = false;

    /**
     * Create a room described "description". Initially, it has
     * no exits. "description" is something like "a kitchen" or
     * "an open court yard".
     */
    public Room(String description, String name) 
    {
        items = new ArrayList();
        objects = new ArrayList();
        droppedItems = new ArrayList();
        this.description = description;
        this.name = name;
        exits = new HashMap();
    }
    
    /**
     * Return the description of the room (the one that was defined
     * in the constructor).
     */
    public String getDescription()
    {
        return description;
    }

    public String getName()
    {
        return name;
    }
    
        public String getLongDescription(String rileysRoom, String cameronsRoom)
    {
        String resultString = "You are " + description + ".";
        if(droppedItems.size() > 0){
            resultString += "\n" + droppedItemsString();
        }
        if(rileysRoom.equals(getName()) && cameronsRoom.equals(getName())){
            resultString += "\n" + "Riley and Cameron are also here.";
        }
        else if(rileysRoom.equals(getName())){
            resultString += "\n" + "Riley is also here.";
        }
        else if(cameronsRoom.equals(getName())){
            resultString += "\n" + "Cameron is also here.";
        }
        resultString += "\n" + getExitString();
        return resultString;
    }
    
    public String droppedItemsString()
    {
        String resultString = "You've left the following items here: ";
        Iterator iter = droppedItems.iterator();
        while(iter.hasNext())
        {
            Item nextItem = (Item) iter.next();
            resultString += "\n" + "\t" + nextItem.toString();
        }
        return resultString;
    }
    
    public String getExitString()
    {
        String resultString = "Exits: ";
        Set<String> keys = exits.keySet();
        for(String exit : keys)
        {
            resultString += " " + exit;
        }
        return resultString;
    }
    
    public Room getExit(String direction)
    {
        return (Room)exits.get(direction);
    }
    
    public void setExit(String direction, Room neighbour)
    {
        exits.put(direction, neighbour);
    }
        
    public void addItem(Item newItem)
    {
        items.add(newItem); 
    }
    
    public ArrayList getItems()
    {
        return items;
    }
    
    public void addObject(Object newObject)
    {
        objects.add(newObject);
    }
    
    public ArrayList getObjects()
    {
        return objects;
    }
    
    public ArrayList getDroppedItems()
    {
        return droppedItems;
    }
    
    public boolean barredRoom()
    {
        boolean barredRoom = false;
        if((getName().equals("road") || getName().equals("castle1") || getName().equals("farmHouse") || getName().equals("castle2")) && unlocked == false){
            barredRoom = true;
        }
        return barredRoom;
    }
    
    public void unlockRoom(){
        unlocked = true;
    }
    
    public void lockRoom(){
        unlocked = false;
    }
    
    public String getLockDescription()
    {
        String lockDescription = "";
        if(name.equals("road")){
            lockDescription += "You can't advance without a password. The gate is barred shut.";
        }
        else if(name.equals("castle1")){
            lockDescription += "The castle gate isn't going to rise unless you figure out what to do" + "\n" + "with that plaque.";
        }
        else if(name.equals("farmHouse")){
            lockDescription += "The door to the farm house has a tight lock. You'll need to use a key" + "\n" + "on the lock to open it.";
        }
        else if(name.equals("castle2")){
            lockDescription += "The door to the second floor is locked. You'll need to find a key" + "\n" + "either in here or the courtyard.";
        }
        return lockDescription;
    }
    
    public String look(String playerRoom, String rileyRoom, String cameronRoom)
    {
        String resultString = "";
        if(playerRoom == "field")
        {
            resultString += "     You stand alone in the field. There are a few trees nearby" +
            "\n" +          "as well as a ravine to your left, but none of these strike you" +
            "\n" +          "as being particularly interesting. Or relevant, for that matter." +
            "\n" +          "You decide that it's probably best to get going.";
        }
        else if(playerRoom == "mainGate1")
        {
            resultString += "     You've made it to the gate of the citadel, but it's locked" +
            "\n" +          "via a conspicuous bar crossing it horizontally. There is a monitor" +
            "\n" +          "on the right wall, but you'll need a password if you want to use" +
            "\n" +          "it. Riley and Cameron are here searching with you, but it doesn't" +
            "\n" +          "look as though they've found anything useful. You guess it's up" +
            "\n" +          "to you to find out how to advance.";
        }
        else if(playerRoom == "mainGate2")
        {
            resultString += "     You're at the main gate of the citadel. The gate, which was" +
            "\n" +          "closed, has already been opened, thanks to you finding the password." +
            "\n" +          "The monitor that had been lit up before is now shut down, with no" +
            "\n" +          "further use. There's probably nothing of interest left over in" +
            "\n" +          "this area.";
        }
        else if(playerRoom == "road")
        {
            resultString += "     The road is mostly dark, with a few street_lights casting" +
            "\n" +          "dim light across the stone ground. A little further ahead, the" +
            "\n" +          "road turns east. A sign shows that following the road east leads" +
            "\n" +          "to the plaza. Going directly north off of where the road turns" +
            "\n" +          "is a path that leads to what looks like a chapel. On the western" +
            "\n" +          "side of the road is the main entrance to the citadel's library." +
            "\n" +          "It has a small mailbox posted just outside the door.";
        }
        else if(playerRoom == "library")
        {
            resultString += "     The library is lined with many shelves. You should examine" +
            "\n" +          "one of them at some point. At the front of the room is a desk." +
            "\n" +          "You assume that this is the 'reception_desk.' At the north" +
            "\n" +          "end of the library is a back exit which probably leads to the" +
            "\n" +          "graveyard next to the church. The main door leading into the" +
            "\n" +          "road is at the east end of the building.";
        }
        else if(playerRoom == "church")
        {
            resultString += "     The church looks smaller on the inside. There are rows of" +
            "\n" +          "pews running down the church, and at the end of them is an altar," +
            "\n" +          "with a couple items on it. At the right of the church is a" +
            "\n" +          "display, which you think you should take a look at when you get" +
            "\n" +          "a chance. Taking the main entrance south will bring you back" +
            "\n" +          "out onto the main road. There's also a door on the western" +
            "\n" +          "side of the church, which leads to the graveyard outside.";
        }
        else if(playerRoom == "graveyard")
        {
            resultString += "     The graveyard  is lined with rows upon rows of graves. One" +
            "\n" +          "of them stands out, and you should probably check it out. Other" +
            "\n" +          "than that, there's really nothing interesting in here. Going" +
            "\n" +          "east will bring you back inside the church. And just south of" +
            "\n" +          "here is a back entrance to the library.";
        }
        else if(playerRoom == "plaza")
        {
            resultString += "     The plaza is lined by rows of street_lights, and has a large" +
            "\n" +          "fountain at its center. However, there's no water running through" +
            "\n" +          "the fountain. North of the plaza is the entrance to the castle" +
            "\n" +          "you saw from before. Going west would take you back along the" +
            "\n" +          "road. East of the plaza is what looks like a large university" +
            "\n" +          "building. And south from here is the entrance to the residential" +
            "\n" +          "sector.";
        }
        else if(playerRoom == "castleEntrance")
        {
            resultString += "     You are standing on a large wooden drawbridge that leads" +
            "\n" +          "north into the castle. However, there is a 'castle_gate' barring" +
            "\n" +          "you from entering. Below you is a moat, which you should probably" +
            "\n" +          "take a closer look at. On the wall next to the gate, there is an" +
            "\n" +          "ornate plaque. Maybe it has something to do with opening the gate?" +
            "\n" +          "If you go back south from here, you will be in the plaza again.";
        }
        else if(playerRoom == "castle1")
        {
            resultString += "     From the cieling hangs a huge chandelier that dominates" +
            "\n" +          "the area. There is also a huge tapestry hanging from the wall." +
            "\n" +          "On the north side of the room is a door that you assume would" +
            "\n" +          "lead to a staircase to the second floor of the castle. On the" +
            "\n" +          "west wall, there is another exit that opens into a courtyard.";
        }
        else if(playerRoom == "courtyard")
        {
            resultString += "     The courtyard is rather small compared to what you thought" +
            "\n" +          "it would be like. There's only a single hedge running along the" +
            "\n" +          "far wall, and a dirt mound in the center. The only spectacular" +
            "\n" +          "aspect of this area is a massive gargoyle that is overlooking" +
            "\n" +          "the courtyard. Resting next to it is a single shovel. The door" +
            "\n" +          "at the east leads back into the castle.";
        }
        else if(playerRoom == "residentialSector")
        {
            resultString += "     The entrance to the residential sector isn't particularly" +
            "\n" +          "interesting, aside from a few street_lights. You'll need to" +
            "\n" +          "go into either the small house to your east, the medium sized" +
            "\n" +          "house to the south, or the huge mansion to the west." +
            "\n" +          "Alternatively, going north will bring you to the plaza.";
        }
        else if(playerRoom == "mansion")
        {
            resultString += "     The mansion has many hallways leading to different rooms." +
            "\n" +          "Here at the main hallyway, a portrait on the wall catches your" +
            "\n" +          "eye, as well as a table rested against the wall under it. It" +
            "\n" +          "looks like there's an item on the table. There are signs along" +
            "\n" +          "the walls which can help to direct you through the mansion." +
            "\n" +          "They say that the south hallway leads to the staircase to the" +
            "\n" +          "bedroom, and the west hallway leads to the kitchen and garden." +
            "\n" +          "Going east out the door will bring you back out to the entrance" +
            "\n" +          "to the residential sector.";
        }
        else if(playerRoom == "kitchen")
        {
            resultString += "     It's a pretty non-descript kitchen. The only noticable" +
            "\n" +          "things about it are an oven and a pantry. Also, there are some" +
            "\n" +          "knives resting on the counter, including a 'bread_knife' or two." +
            "\n" +          "You might need to take one of them. There's a door at the west" +
            "\n" +          "end of the room that opens out into a garden, and the door east" +
            "\n" +          "brings you back to the main hallway of the mansion.";
        }
        else if(playerRoom == "bedroom")
        {
            resultString += "     There are a few neat aspects of this bedroom. There is" +
            "\n" +          "a 'canopy_bed' in the corner, and a vanity next to it. It also" +
            "\n" +          "looks like there's a safe on the vanity. That's probably" +
            "\n" +          "going to be important.";
        }
        else if(playerRoom == "garden")
        {
            resultString += "     The garden is incredibly cramped. There are only a few" +
            "\n" +          "bushes, including a 'bramble_bush'. There's also a tall fence" +
            "\n" +          "enclosing the area. Going east will bring you back into the" +
            "\n" +          "kitchen.";
        }
        else if(playerRoom == "smallHouse")
        {
            resultString += "     This house barely qualifies as a home. In your opinion," +
            "\n" +          "it's more like a shed than anything. Laying on the floor" +
            "\n" +          "is a scalpel, for a reason that only God knows, and a string." +
            "\n" +          "You have a feeling that they're both important. Going north" +
            "\n" +          "will get you to the university. Going south leads to the" +
            "\n" +          "watch tower you saw when you were outside the citadel. And" +
            "\n" +          "going west would have you back in the outside of the residential" +
            "\n" +          "sector.";
        }
        else if(playerRoom == "mediumHouse")
        {
            resultString += "     You don't really think it's too important to explore this" +
            "\n" +          "house fully. In the first room you enter, there's a vase with" +
            "\n" +          "water in it resting on a table. It's rather eery that it's the" +
            "\n" +          "only thing in the room. Except that next to the vase, there is" +
            "\n" +          "a ladle. You can probably take it for later. The only direction" +
            "\n" +          "to go from here is north, back to the residential sector's entrance.";
        }
        else if(playerRoom == "watchTower")
        {
            resultString += "     The watch tower is practically in shambles. There's a" +
            "\n" +          "'wooden_staircase', but you're not sure how safe it is. Aside from" +
            "\n" +          "that, the place is a mess. There's nothing here that could possibly" +
            "\n" +          "be useful. You'd better go north, back to the small house.";
        }
        else if(playerRoom == "university")
        {
            resultString += "     You're in the university's hallway. There are a few doors," +
            "\n" +          "but you doubt that they're all unlocked. Except for one; an" +
            "\n" +          "open door labeled \"infirmary,\" at the end of the eastern" +
            "\n" +          "hallway. Also, there's a broom resting against the wall next" +
            "\n" +          "to you. The west exit leads back out into the plaza, and the" +
            "\n" +          "south exit leads down a path heading to the small house in the" +
            "\n" +          "residential sector. There's also an exit at the end of the" +
            "\n" +          "north hallway, which seems to open onto a ranch.";
        }
        else if(playerRoom == "infirmary")
        {
            resultString += "     The infirmary is pretty small. There's a table with a" +
            "\n" +          "lump covered by a sheet on it. Is it a... corpse? There's only" +
            "\n" +          "one way to find out. Otherwise, you can take the door west into" +
            "\n" +          "the hallway.";
        }
        else if(playerRoom == "ranch")
        {
            resultString += "     It's a big, wide ranch. There is a lot of hay scattered" +
            "\n" +          "around the area, and some stacks of it. There's also a fence" +
            "\n" +          "surrounding the perimeter. To the north is a small farm house" +
            "\n" +          "that looks conspicuous, but you can't get in because there is" +
            "\n" +          "a lock latched on to the door. Rested against the building is" +
            "\n" +          "a rake that you can take. Going back south will bring you to" +
            "\n" +          "the university building.";
        }
        else if(playerRoom == "farmHouse")
        {
            resultString += "     The inside of the farm house is very cramped. There's" +
            "\n" +          "only room for one small table, which has a pair of shears and" +
            "\n" +          "a chest. It's a rather odd place to put a locked chest, but" +
            "\n" +          "who are you to judge? The only way out of the house is south," +
            "\n" +          "back out onto the ranch.";
        }
        
        if(playerRoom == rileyRoom && playerRoom == cameronRoom){
            resultString += "\n" + "     Riley and Cameron are also here.";
        }
        else if(playerRoom == rileyRoom){
            resultString += "\n" + "     Riley is also here.";
        }
        else if(playerRoom == cameronRoom){
            resultString += "\n" + "     Cameron is also here." ;
        }
        if(droppedItems.size() > 0){
            resultString += "\n" + "     " + droppedItemsString();
        }
        return resultString;
    }
}
