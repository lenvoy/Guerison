
public class Examine
{
    private boolean action;
    private int password;
    
    private boolean monitor;
    private boolean barCheck;
    private boolean paperCheck;
    private boolean mailboxCheck;
    private boolean townHistoryCheck;
    private boolean napoleonCheck;
    private boolean tellingPoolCheck;
    private boolean altarCheck;
    private boolean graveCheck;
    private boolean fountainCheck;
    private boolean putRosary;
    private boolean checkMoat;
    private boolean pantryCheck;
    private boolean safe;
    private boolean brambleBeGone;
    private boolean flowerVase;
    private boolean cutCorpse;
    private boolean checkedCorpse;
    private boolean checkHaystack;
    private boolean unlockFarm;
    private boolean unlockChest;
    
    public boolean sapphire;
    public boolean ruby;
    public boolean emerald;
    
    private boolean openCastle;
    private boolean unlockedDoor;
    private boolean dugDirt;
    
    private String equip;

    /**
     * Constructor for objects of class Examine
     */
    public Examine(){
    }
    
    public void setEquip(String e)
    {
        equip = e;
    } 
    
    public boolean getAction()
    {
        return action;
    }
    
    public boolean getOpenCastle()
    {
        return openCastle;
    }
    
    public int getPassword()
    {
        return password;
    }
    
    public void resetPassword()
    {
        password = 0;
    }
    
    public String alterExamine(int z)
    {
        String examined = "";
        switch(z)
        {
            case 1:
            examined = "monitor";
            monitor = true;
            barCheck = true;
            break;
            case 2:
            safe = true;
            examined = "safe";
            break;
        }
        return examined;
    }

    /**
     * Prints out the information from examining an item.
     */
    public String examineItem(String item)
    {
        action = false;
        String examineString = "";
        if(item.equals("paper") && paperCheck == false)
        {
            examineString += "     The small piece of paper from behind the bar is folded";
            examineString += "\n" + "so that you can't see what it says. You unfold it, and as";
            examineString += "\n" + "you expected, it has a 4-digit code written on it. It reads";
            examineString += "\n" + "'9806'.";
            paperCheck = true;
        }
        else if(item.equals("paper") && paperCheck == true)
        {
            examineString += "     It's a scrap of paper that you found tucked behind";
            examineString += "\n" + "the bar at the main gate. It has the code '9806' on it.";
        }
        else if(item.equals("letter"))
        {
            examineString += "     You open the letter and read it. It says:";
            examineString += "\n" + "          \"I am writing to request that the following books";
            examineString += "\n" + "          be delivered to my mansion in the residential";
            examineString += "\n" + "          sector: 'town_history', 'napoleon_biography', and";
            examineString += "\n" + "          'the_telling_pool'. I have an important use for them.\"";
        }
        else if(item.equals("town_history") && townHistoryCheck == false)
        {
            examineString += "     You're pretty curious about the history of this citadel,";
            examineString += "\n" + "so you decide to read a few paragraphs out of this book.";
            examineString += "\n" + "          \"Throughout the war, Besancon served as a station";
            examineString += "\n" + "     for wounded troops to recuperate before returning to their";
            examineString += "\n" + "     legions and participating in the war effort. During this";
            examineString += "\n" + "     time, the city gained its title of \"Guerison.\" Upon";
            examineString += "\n" + "     leaving the city, soldiers would comment on the relaxing";
            examineString += "\n" + "     atmosphere of the city, and its almost supernatural";
            examineString += "\n" + "     capacity for healing. Years later...\"";
            examineString += "\n" + "     Hey, there's a note sticking out of one of the other pages.";
            examineString += "\n" + "You flip to that page, and find that stuck to it is a scrap of";
            examineString += "\n" + "paper with the letter 'R' written on it.";
            townHistoryCheck = true;
        }
        else if(item.equals("town_history") && townHistoryCheck == true)
        {
            examineString += "     The piece of paper tucked inside the book has an 'R' on it.";
        }
        else if(item.equals("napoleon_biography") && napoleonCheck == false)
        {
            examineString += "     You really have no interest in reading about Napoleon. You";
            examineString += "\n" + "quickly scan the pages and find that there's a note tucked in";
            examineString += "\n" + "one of them, with the letter 'U' written on it.";
        }
        else if(item.equals("napoleon_biography") && napoleonCheck == true)
        {
            examineString += "     The piece of paper tucked inside the book has a 'U' on it.";
        }
        else if(item.equals("the_telling_pool") && tellingPoolCheck == false)
        {
            examineString += "     It looks like a fiction novel. Something about the Crusades,";
            examineString += "\n" + "magic, wicked temptresses, and... falcons? To be honest it doesn't";
            examineString += "\n" + "look like your kind of thing. You skim through it and sure enough,";
            examineString += "\n" + "find a ripped piece of notebook paper between the pages. It has";
            examineString += "\n" + "the letter 'N' written on it.";
        }
        else if(item.equals("the_telling_pool") && tellingPoolCheck == true)
        {
            examineString += "     The piece of paper tucked inside the book has an 'N' on it.";
        }
        else if(item.equals("bible"))
        {
            examineString += "     At first glance, it's a normal bible. But on closer";
            examineString += "\n" + "inspection, you notice some papers stuffed between the pages.";
            examineString += "\n" + "They look like biology notes. Let's see... Oh God, that is";
            examineString += "\n" + "so wrong. It's something about using scalpels to perform";
            examineString += "\n" + "autopsies, all gross stuff. You hope you never have to do";
            examineString += "\n" + "any of this stuff.";
        }
        else if(item.equals("small_crucifix"))
        {
            examineString += "     \"The power of christ compels you.\" To be honest, you";
            examineString += "\n" + "have no idea why you just said that. Maybe you heard it from";
            examineString += "\n" + "somewhere. It's probably not important. Anyway, there is";
            examineString += "\n" + "something unusual about this crucifix, besides it's size. It";
            examineString += "\n" + "has a little hole at the top of it.";
        }
        else if(item.equals("bouquet"))
        {
            examineString += "     It really is a beautiful bouquet. You should find someplace";
            examineString += "\n" + "to put it.";
        }
        else if(item.equals("coin"))
        {
            examineString += "     It's a gold coin. It has a graphic of the sower on the";
            examineString += "\n" + "front, so you assume that it must be from the beginning of the";
            examineString += "\n" + "previous century.";
        }
        else if(item.equals("beads"))
        {
            examineString += "     The beads look as though they can be strung. Is there anything";
            examineString += "\n" + "that you need to make using beads?";
        }
        else if(item.equals("bread_knife"))
        {
            examineString += "     It's just a knife for cutting bread. Take a hint.";
        }
        else if(item.equals("bread") && !equip.equals("bread_knife"))
        {
            examineString += "     It's a loaf of bread. You could probably cut it with a knife.";
        }
        else if(item.equals("bread") && equip.equals("bread_knife"))
        {
            examineString += "     You cut open the bread with the knife and obtain a 'gold_key'.";
            action = true;
            
        }
        else if(item.equals("journal"))
        {
            examineString += "     This journal looks very old. When you open it up, only the";
            examineString += "\n" + "first page has actual writing on it. The entry reads as follows:";
            examineString += "\n" + "          \"It's been a month since I've purchased that wretched";
            examineString += "\n" + "     farm house, and the only use I've really found of it is to";
            examineString += "\n" + "     store my sapphire gemstone. It's in a chest inside. Of course,";
            examineString += "\n" + "     you'd need the key to get into the chest. Speaking of keys,";
            examineString += "\n" + "     I can never remember where I keep the key to that farm house,";
            examineString += "\n" + "     so I might as well remind myself here. It's hidden in the";
            examineString += "\n" + "     'fourth_haystack' at the ranch outside. Hopefully now I won't";
            examineString += "\n" + "     forget. We'll see.";
        }
        else if(item.equals("tape"))
        {
            examineString += "     It's a roll of duct tape. You can use it to hold things together.";
        }
        else if(item.equals("scalpel"))
        {
            examineString += "     It's used for performing autopsies and disecting specimens. You";
            examineString += "\n" + "have no idea how it could be useful, but you never know.";
        }
        else if(item.equals("string"))
        {
            examineString += "     It's probably only good for if you want to make something";
            examineString += "\n" + "crafty. In other words, you should combine it with something.";
        }
        else if(item.equals("ladle"))
        {
            examineString += "     Ladles are perfect for scooping things. Is there something";
            examineString += "\n" + "you need to scoop?";
        }
        else if(item.equals("broom"))
        {
            examineString += "     It's just a normal broom. Except... It looks like the bottom";
            examineString += "\n" + "part is loose. You pull it off, and obtain the 'broom_handle'.";
            action = true;
        }
        else if(item.equals("super_glue"))
        {
            examineString += "     You can probably use this to stick two items together. It";
            examineString += "\n" + "says on the label that it dries very fast and holds tight.";
        }
        else if(item.equals("farm_key"))
        {
            examineString += "     It's the key that opens the lock on the door to the farm house.";
        }
        else if(item.equals("rake"))
        {
            examineString += "     It's just a normal rake. Except... It looks like the bottom";
            examineString += "\n" + "part is loose. You pull it off, and obtain the 'rake_handle'.";
            action = true;
        }
        else if(item.equals("emerald"))
        {
            examineString += "     It's a beautiful emerald. It looks as though it would";
            examineString += "\n" + "fit inside one of the nitches in the 'castle_gate'.";
        }
        else if(item.equals("sapphire"))
        {
            examineString += "     It's a gorgeous sapphire. It looks as though it would";
            examineString += "\n" + "fit inside one of the nitches in the 'castle_gate'.";
        }
        else if(item.equals("ruby"))
        {
            examineString += "     It's an incredible ruby. It looks as though it would";
            examineString += "\n" + "fit inside one of the nitches in the 'castle_gate'.";
        }
        else if(item.equals("shovel"))
        {
            examineString += "     It's just a regular old shovel. You can probably find";
            examineString += "\n" + "somewhere to dig around here.";
        }
        else if(item.equals("skeleton_key"))
        {
            examineString += "     This key should technically be able to unlock any room in";
            examineString += "\n" + "the castle, but there's really only one door you would need to";
            examineString += "\n" + "get through.";
        }
        else if(item.equals("gold_key"))
        {
            examineString += "     A key made of solid gold. At least, it looks like it is.";
            examineString += "\n" + "Either way, the point is that it probably opens something golden.";
        }
        else if(item.equals("broom_handle"))
        {
            examineString += "     The handle to a broom. It will be useful if you need a long";
            examineString += "\n" + "stick for whatever reason. If you were to somehow tape it to";
            examineString += "\n" + "another stick, that would be even better.";
        }
        else if(item.equals("rake_handle"))
        {
            examineString += "     The handle to a rake. It will be useful if you need a long";
            examineString += "\n" + "stick for whatever reason. If you were to somehow tape it to";
            examineString += "\n" + "another stick, that would be even better.";
        }
        else if(item.equals("long_stick"))
        {
            examineString += "     A long stick you made by taping together the broom handle and";
            examineString += "\n" + "the rake handle. All it needs now is something attached to the end";
            examineString += "\n" + "and it would be perfect for scooping up that 'shiny_item' in the";
            examineString += "\n" + "moat.";
        }
        else if(item.equals("scoopertron_2000"))
        {
            examineString += "     It took a lot of work to put this thing together. Hopefully it";
            examineString += "\n" + "can do its job well enough to make it all worth it.";
        }
        else if(item.equals("rosary"))
        {
            examineString += "     You made this rosery by combining the beads, string, and small";
            examineString += "\n" + "crucifix. You should probably put it in the display back at the";
            examineString += "\n" + "church. Who knows, something might happen.";
        }
        else if(item.equals("shears"))
        {
            examineString += "     It's a pretty standard pair of gardening shears. Something any";
            examineString += "\n" + "self-respecting farm hand would carry around. Is there anything";
            examineString += "\n" + "that you need them for?";
        }
        return examineString;
    }
    
    /**
     * Prints out the information from examining an object.
     */
    public String examineObject(String object)
    {
        action = false;
        String examineString = "";
        if(object.equals("gate") && monitor == false)
        {   examineString += "     The gate is sturdy and not about the budge. This is";
            examineString += "\n" + "mostly thanks to the bar that blocks it from opening.";
        }
        else if(object.equals("gate") && monitor == true)
        {
            examineString += "     The right door of the gate is opened wide. There's no";
            examineString += "\n" + "reason to go outside though.";
        }
        else if(object.equals("wall"))
        {
            examineString += "     The wall surrounding the gate looks to be made of...";
            examineString += "\n" + "marble? Either way, it doesn't look like there's anything";
            examineString += "\n" + "interesting about it, besides the monitor on the right.";
        }
        else if(object.equals("monitor") && monitor == false)
        {
            examineString += "     The monitor's screen is lit, and on it there are four";
            examineString += "\n" + "spaces for you to input a password. When you tap one, it";
            examineString += "\n" + "displays a list of ten digits, from 0 to 9, for you to";
            examineString += "\n" + "select. Please input the password.";
            password = 1;
        }
        else if(object.equals("monitor") && monitor == true)
        {
            examineString += "     The monitor has shut down since you put in the correct";
            examineString += "\n" + "password. There's probably no further use for it.";
        }
        else if(object.equals("bar") && barCheck == false)
        {
            examineString += "     It's a wooden bar that holds the gate shut. There's";
            examineString += "\n" + "nothing else too interesting about it, except... what's";
            examineString += "\n" + "that tucked behind it? It looks like paper. Maybe you can";
            examineString += "\n" + "take it out.";
            barCheck = true;
        }
        else if(object.equals("bar") && barCheck == true)
        {
            examineString += "     It's just the wooden bar that holds the gate shut.";
        }
        else if(object.equals("street_lights"))
        {
            examineString += "     You're suprised that these lights are still functional,";
            examineString += "\n" + "but grateful for the dim light that they provide. Aside from";
            examineString += "\n" + "that, there's really nothing special about them.";
        }
        else if(object.equals("mailbox") && mailboxCheck == false)
        {
            examineString += "     The mailbox posted outside the library has it's flag put";
            examineString += "\n" + "up. Curious, you check to see if there's anything left inside";
            examineString += "\n" + "of it and... Yep. Just as you expected, there's a single letter";
            examineString += "\n" + "inside the mailbox.";
            mailboxCheck = true;
        }
        else if(object.equals("mailbox") && mailboxCheck == true)
        {
            examineString += "     It's the mailbox that the letter was in.";
        }
        else if(object.equals("sign"))
        {
            examineString += "     The sign reads \"East to Plaza.\" This means that if you";
            examineString += "\n" + "follow the road east, it will lead you to the plaza.";
        }
        else if(object.equals("road"))
        {
            examineString += "     The road is made of stone. Considering the grandeur of the";
            examineString += "\n" + "citadel, you're surprised it's not made of mosaic tiles or";
            examineString += "\n" + "something equally incredible.";
        }
        else if(object.equals("shelf"))
        {
            examineString += "     The shelves in this library are lined with huge rows of";
            examineString += "\n" + "books. It's pointless to try going through every one of them,";
            examineString += "\n" + "but they are organized alphabetically by title. If you had an";
            examineString += "\n" + "idea of which book you wanted to take, you could probably find";
            examineString += "\n" + "it easily enough.";
        }
        else if(object.equals("reception_desk"))
        {
            examineString += "     There's nothing too spectacular about this desk, except";
            examineString += "\n" + "that there are a few computers, presumably for checking out";
            examineString += "\n" + "books. None of them seem to be turned on, however. There's a";
            examineString += "\n" + "sticky note posted onto one of them. It seems to be a reminder";
            examineString += "\n" + "for the librarian to check the mailbox, because they were";
            examineString += "\n" + "apparently expecting a very important letter.";
        }
        else if(object.equals("altar") && altarCheck == false)
        {
            examineString += "     There are a few miscellaneous religious artifacts strewn";
            examineString += "\n" + "around the altar. Among them, a bible and a small_crucifix both";
            examineString += "\n" + "catch your eye.";
            altarCheck = true;
        }
        else if(object.equals("altar") && altarCheck == true)
        {
            examineString += "     It's the altar that had a bible and small_crucifix on it.";
        }
        else if(object.equals("pews"))
        {
            examineString += "     Hey, these pews have cushions on them!... But you really";
            examineString += "\n" + "don't have time to sit down and rest. Maybe another day.";
        }
        else if(object.equals("display") && putRosary == true)
        {
            examineString += "     You have no further use for the display case with the";
            examineString += "\n" + "rosary in it. You need to move on and look for more clues.";
        }
        else if(object.equals("display") && !equip.equals("rosary"))
        {
            examineString += "     It's a display case, but there's nothing in it. You seem";
            examineString += "\n" + "to be able to open the glass. There's also a small engraving";
            examineString += "\n" + "on the wood inside the case. It looks like a rosary. You assume";
            examineString += "\n" + "that must be what is meant to go in the case.";
        }
        else if(object.equals("display") && equip.equals("rosary"))
        {
            examineString += "     You put the rosary in the display case, and hear a clicking";
            examineString += "\n" + "sound. The wooden panel under the display case falls out and along";
            examineString += "\n" + "with it, a gemstone. It looks like a ruby.";
            putRosary = true;
            action = true;
        }
        else if(object.equals("grave") && graveCheck == false)
        {
            examineString += "     There are many graves that line the area, but one stands";
            examineString += "\n" + "out because it's the only one that has a bouquet by its side.";
            examineString += "\n" + "A chill runs down your spine as you realize that someone must";
            examineString += "\n" + "have come and put it here recently, or else the flowers would";
            examineString += "\n" + "have died a while ago.";
            graveCheck = true;
        }
        else if(object.equals("grave") && graveCheck == true)
        {
            examineString += "     It's the grave that had a bouquet by it.";
        }
        else if(object.equals("fountain") && fountainCheck == false)
        {
            examineString += "     The fountain doesn't look like it's used running water";
            examineString += "\n" + "in a long time. However, it definitely had water at some point,";
            examineString += "\n" + "because there are lots of coins inside it that people must have";
            examineString += "\n" + "thrown in at some point. You suppose you can take one.";
            fountainCheck = true;
        }
        else if(object.equals("fountain") && fountainCheck == true)
        {
            examineString += "     The fountain doesn't look like it's used running water";
            examineString += "\n" + "in a long time. However, it definitely had water at some point,";
            examineString += "\n" + "because there are lots of coins inside it that people must have";
            examineString += "\n" + "thrown in at some point.";
        }
        else if(object.equals("stairs"))
        {
            examineString += "     At the south end of the mansion is a staircase that would";
            examineString += "\n" + "lead to what you guess is a bedroom or two.";
        }
        else if(object.equals("portrait"))
        {
            examineString += "     It's a portrait of a very pompous-looking woman. You have";
            examineString += "\n" + "no idea who she could have been, but she must have been very";
            examineString += "\n" + "important to live in a mansion like this.";
        }
        else if(object.equals("table"))
        {
            examineString += "     The table is right next to the wall. There's a doily on it,";
            examineString += "\n" + "as well as a box of... beads? What could there be beads here for?";
        }
        else if(object.equals("oven"))
        {
            examineString += "     The oven doesn't look as though it's been used in a long";
            examineString += "\n" + "time. There's nothing in it either.";
        }
        else if(object.equals("pantry") && pantryCheck == false)
        {
            examineString += "     The pantry cabinet has almost nothing in it. There is some";
            examineString += "\n" + "bread, though. Maybe you should take one and cut it in half.";
            pantryCheck = true;
        }
        else if(object.equals("pantry") && pantryCheck == true)
        {
            examineString += "     It's just a pantry cabinet with bread in it.";
        }
        else if(object.equals("canopy_bed"))
        {
            examineString += "     It's a canopy bead, and the top of it reaches the ceiling.";
            examineString += "\n" + "A quick search of the pillows and sheets comes up with nothing.";
            examineString += "\n" + "You doubt you need to do anything with the bed.";
        }
        else if(object.equals("vanity"))
        {
            examineString += "     You look in the mirror and... Yikes, you look terrible. You";
            examineString += "\n" + "definitely shouldn't have skipped out on breakfast this morning.";
            examineString += "\n" + "The safe is also on the vanity.";
        }
        else if(object.equals("safe") && safe == false)
        {
            examineString += "     The safe is sealed shut. You'll need to put in a passcode of";
            examineString += "\n" + "some sort in order to open it. It looks like it takes three letters,";
            examineString += "\n" + "in all capitals. Please input the password.";
            
            password = 2;
        }
        else if(object.equals("safe") && safe == true)
        {
            examineString += "     You've already opened this safe. As long as you have the";
            examineString += "\n" + "journal, you won't need it for anything else.";
        }
        else if(object.equals("bramble_bush") && brambleBeGone == true)
        {
            examineString += "     The brambles have been cut away thanks to the shears. They";
            examineString += "\n" + "won't be a problem anymore.";
        }
        else if(object.equals("bramble_bush") && equip.equals("shears"))
        {
            examineString += "     You use the shears to cut away some of the brambles. You";
            examineString += "\n" + "think you can reach the tape now.";
            brambleBeGone = true;
            action = true;
        }
        else if(object.equals("bramble_bush") && brambleBeGone == false)
        {
            examineString += "     It's a thick bush of brambles. Hidden among them you can";
            examineString += "\n" + "see a roll of tape, but it's too difficult to get it out. There";
            examineString += "\n" + "must be a tool you can use to get rid of the brambles.";
        }
        else if(object.equals("fence"))
        {
            examineString += "     It's just a wooden fence that surrounds the area.";
        }
        else if(object.equals("vase") && flowerVase == true)
        {
            examineString += "     It's a vase with flowers in it.";
        }
        else if(object.equals("vase") && equip.equals("bouquet"))
        {
            examineString += "     You put the bouquet you found in the vase aaaaand... Nothing.";
            examineString += "\n" + "What a let-down. You had expected a secret passageway or something,";
            examineString += "\n" + "but it turns out all you're getting out of this is the satisfaction";
            examineString += "\n" + "of saving a few flowers.";
            flowerVase = true;
            action = true;
        }
        else if(object.equals("vase") && flowerVase == false)
        {
            examineString += "     It's an empty vase, but it is filled with a decent amount of";
            examineString += "\n" + "water. It would look nice with a bouquet of flowers.";
        }
        else if(object.equals("wooden_staircase"))
        {
            examineString += "     The staircase leading to the second floor of the watch tower is";
            examineString += "\n" + "totally busted. Most of the steps are broken, and what is in tact";
            examineString += "\n" + "probably isn't very sturdy. You decide not to bother with it.";
        }
        else if(object.equals("doors"))
        {
            examineString += "     All of the non-exit doors in the building are locked, except for";
            examineString += "\n" + "the one going east towards the infirmary.";
        }
        else if((object.equals("corpse") || object.equals("dummy")) && equip.equals("scalpel"))
        {
            examineString += "     You slice open the \"corpse's\" chest with your scalpel, and";
            examineString += "\n" + "inside is some 'super_glue'.";
            checkedCorpse = true;
            cutCorpse = true;
            action = true;
        }
        else if((object.equals("corpse") || object.equals("dummy")) && checkedCorpse == false)
        {
            examineString += "     On closer inspection, it's not actually a real corpse, but a";
            examineString += "\n" + "dummy. You feel rather silly for thinking otherwise. Nonetheless,";
            examineString += "\n" + "you still need to do something with it. What could a dummy be";
            examineString += "\n" + "used for in a university?";
            checkedCorpse = true;
        }
        else if((object.equals("corpse") || object.equals("dummy")) && checkedCorpse == true 
        && cutCorpse == false)
        {
            examineString += "     What could the dummy be for? Maybe you have to perform some";
            examineString += "\n" + "scientific procedure on it?";
        }
        else if((object.equals("corpse") || object.equals("dummy")) && cutCorpse == true)
        {
            examineString += "     \"The operation was a success.\" In all seriousness, there's";
            examineString += "\n" + "really no reason to still be hanging around this dummy. It's job";
            examineString += "\n" + "is done.";
        }
        else if(object.equals("hay"))
        {
            examineString += "     There are tons of haystacks scattered across the ranch. You";
            examineString += "\n" + "have a feeling that something important is in one of them, but you";
            examineString += "\n" + "haven't got the slightest idea which one. You should look around";
            examineString += "\n" + "for more clues.";
        }
        else if(object.equals("fourth_haystack") && checkHaystack == false)
        {
            examineString += "     You rifle through the haystack that was mentioned in the";
            examineString += "\n" + "journal. With no small amount of difficulty, you eventually find";
            examineString += "\n" + "a key. You assume this must be the 'farm_key' to get into the farm";
            examineString += "\n" + "house to the north. You should take it.";
            checkHaystack = true;
            action = true;
        }
        else if(object.equals("fourth_haystack") && checkHaystack == true)
        {
            examineString += "     It's the haystack that you found the 'farm_key' in.";
        }
        else if(object.equals("lock") && equip.equals("farm_key"))
        {
            examineString += "     You use the farm_key on the lock, and it clicks open. You now";
            examineString += "\n" + "have unrestricted access to the farm house.";
            unlockFarm = true;
            action = true;
        }
        else if(object.equals("lock") && unlockFarm == true)
        {
            examineString += "     You've already unlocked the farm house. You don't need to worry";
            examineString += "\n" + "about this lock anymore.";
        }
        else if(object.equals("lock") && unlockFarm == false)
        {
            examineString += "     This lock is keeping the door into the farm house firmly shut.";
            examineString += "\n" + "You'll need to use a specific key to unlock it.";
        }
        else if(object.equals("chest") && equip.equals("gold_key"))
        {
            examineString += "     You try to unlock the golden chest with your gold_key and...";
            examineString += "\n" + "It works! It opens up, and you can see that inside is a sapphire";
            examineString += "\n" + "gemstone.";
            unlockChest = true;
            action = true;
        }
        else if(object.equals("chest") && unlockChest == true)
        {
            examineString += "     You don't need this chest for anything now.";
        }
        else if(object.equals("chest") && unlockChest == false)
        {
            examineString += "     The chest looks to be made out of gold, or at least coated with";
            examineString += "\n" + "something that looks like it. As such, if you want to open it you";
            examineString += "\n" + "will probably need to use a key that is also golden.";
        }
        else if(object.equals("castle_gate") && openCastle == false)
        {
            examineString += "     The gate is made of iron bars. There's no way they're wide";
            examineString += "\n" + "enough to slip through. You're going to have to figure out some";
            examineString += "\n" + "way to open this gate if you want to get inside the castle.";
        }
        else if(object.equals("castle_gate") && openCastle == true)
        {
            examineString += "     The gate has been lifted. There's nothing stopping you from";
            examineString += "\n" + "going inside the castle now.";
        }
        else if(object.equals("drawbridge"))
        {
            examineString += "     The drawbridge is down, which allows you to walk right up";
            examineString += "\n" + "to the gate which serves as an entrance to the castle. If it";
            examineString += "\n" + "weren't for this drawbridge, you'd be going through the moat to";
            examineString += "\n" + "cross.";
        }
        else if(object.equals("plaque") && equip.equals("sapphire"))
        {
            examineString += "     You take the sapphire you found and try to place it in";
            examineString += "\n" + "the niche at the right of the plaque. And, it fits like a";
            examineString += "\n" + "glove!";
            sapphire = true;
            if(!openCastle().equals(""))
            {
                examineString += "\n" + openCastle();
            }
            action = true;
        }
        else if(object.equals("plaque") && equip.equals("ruby"))
        {
            examineString += "     You take the ruby you found and try to place it in the";
            examineString += "\n" + "niche at the left of the plaque. And, it fits like a glove!";
            ruby = true;
            if(!openCastle().equals(""))
            {
                examineString += "\n" + openCastle();
            }
            action = true;
        }
        else if(object.equals("plaque") && equip.equals("emerald"))
        {
            examineString += "     You take the emerald you found and try to place it in the";
            examineString += "\n" + "niche at the center of the plaque. And, it fits like a glove!";
            emerald = true;
            if(!openCastle().equals(""))
            {
                examineString += "\n" + openCastle();
            }
            action = true;
        }
        else if(object.equals("plaque") && openCastle == false)
        {
            examineString += "     On the wall next to the gate, there is a large plaque";
            examineString += "\n" + "that reads \"The Royal Family of Guerison.\" You assume that it";
            examineString += "\n" + "must be referencing the family that ruled over this town and had";
            examineString += "\n" + "lived in this castle. Another interesting feature of the plaque";
            examineString += "\n" + "is that near the bottom are three niches where something can be";
            examineString += "\n" + "placed into. You probably have to put a specific item in all";
            examineString += "\n" + "three in order to open the gate.";
        }
        else if(object.equals("plaque") && openCastle == true)
        {
            examineString += "     You have no further use for this plaque. You wish you";
            examineString += "\n" + "could have kept the gemstones, though...";
        }
        else if(object.equals("moat") && checkMoat == false)
        {
            examineString += "     The moat is very shallow, probably because it comes from";
            examineString += "\n" + "the nearly dried out river that you saw outside of the citadel.";
            examineString += "\n" + "Actually, it's shallow enough that you can see some sort of";
            examineString += "\n" + "shiny_item at the bottom. Of course, you can't reach it. Maybe if";
            examineString += "\n" + "you had something a few feet long, you would be able to scoop it";
            examineString += "\n" + "up and take it?";
            checkMoat = true;
        }
        else if(object.equals("moat") && checkMoat == true)
        {
            examineString += "     It's just a shallow moat. Last time you checked, you could";
            examineString += "\n" + "see a shiny_item at the bottom.";
        }
        else if(object.equals("tapestry"))
        {
            examineString += "     The tapestries are gorgeous, but they're so high up that";
            examineString += "\n" + "there's no way you can reach them. They're probably unimportant";
            examineString += "\n" + "aside from their aesthetic purpose.";
        }
        else if(object.equals("door") && equip.equals("skeleton_key"))
        {
            examineString += "     You slide the key into the lock and... You're in!";
            unlockedDoor = true;
            action = true;
        }
        else if(object.equals("door") && unlockedDoor == true)
        {
            examineString += "     The door to the north staircase is unlocked. You can go to";
            examineString += "\n" + "the second floor of the castle now.";
        }
        else if(object.equals("door") && unlockedDoor == false)
        {
            examineString += "     This is the door to the northeast Staircase. It is currently";
            examineString += "\n" + "locked. You'll need to find a key either in here or in the courtyard";
            examineString += "\n" + "in order to unlock it and advance.";
        }
        else if(object.equals("chandelier"))
        {
            examineString += "     It's a grand chandelier that hangs high above you. If you";
            examineString += "\n" + "didn't know any better, you would say that it was sparkling so";
            examineString += "\n" + "purely that it could be made entirely out of diamonds. This is";
            examineString += "\n" + "truly a sight to behold.";
        }
        else if(object.equals("dirt_mound") && equip.equals("shovel"))
        {
            examineString += "     You take the shovel and start digging. It doesn't take long";
            examineString += "\n" + "before you notice a box in the dirt. You open it, and inside is";
            examineString += "\n" + "a key with a skull graphic on it. You assume that this must be a";
            examineString += "\n" + "'skeleton_key'.";
            dugDirt = true;
            action = true;
        }
        else if(object.equals("dirt_mound") && dugDirt == false)
        {
            examineString += "     It's just a mound of dirt, but it does look rather";
            examineString += "\n" + "conspicuous in the middle of the courtyard. Is there any way you";
            examineString += "\n" + "can dig through it?";
        }
        else if(object.equals("dirt_mound") && dugDirt == true)
        {
            examineString += "     There's actually a hole where the dirt mound used to be. You";
            examineString += "\n" + "doubt you'll need to do any more digging around here.";
        }
        else if(object.equals("gargoyle"))
        {
            examineString += "     This reminds you of one of those animated cartoons your father";
            examineString += "\n" + "had you watch when you were young. Now that you think about it, it's";
            examineString += "\n" + "pretty incredible that he managed to get those century-old cartoons";
            examineString += "\n" + "for you to watch.";
        }
        else if(object.equals("hedge"))
        {
            examineString += "     You look the hedge over. It doesn't look like there's";
            examineString += "\n" + "anything of interest hidden within it.";
        }
        return examineString;
    }
    
    private String openCastle()
    {
        String resultString = "";
        if(ruby == true && emerald == true && sapphire == true)
        {
            openCastle = true;
            resultString += "     All three gemstones are situated in the plaque, and the";
            resultString += "\n" + "gate slowly begins to rise out of the way. You hope that this";
            resultString += "\n" + "test is almost over.";
        }
        return resultString;
    }
}
