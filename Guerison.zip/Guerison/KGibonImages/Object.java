
/**
 * Sets the interactable objects of the game.
 */
public class Object
{
    String x;

    public Object(String description)
    {
        this.x = description;
    }

    public String toString()
    {
        return x;
    }
}
