import java.util.StringTokenizer;

class Parser 
{
    private CommandWords commands;  // holds all valid command words
    private boolean correct1 = false;
    private boolean correct2 = false;
    private boolean correct3 = false;
    private boolean endGame = false;
    
    public Parser() 
    {
        commands = new CommandWords();
    }

    public Command getCommand(String inputLine) 
    {
        String word1;
        String word2;

        StringTokenizer tokenizer = new StringTokenizer(inputLine);

        if(tokenizer.hasMoreTokens())
            word1 = tokenizer.nextToken();      // get first word
        else
            word1 = null;
        if(tokenizer.hasMoreTokens())
            word2 = tokenizer.nextToken();      // get second word
        else
            word2 = null;

        if(commands.isCommand(word1))
            return new Command(word1, word2);
        else
            return new Command(null, word2);
    }
    
    public String enterPassword(int monitor, String pass)
    {
        String resultString = "";
        
        switch(monitor) // tests to see if the password is correct, and gives feedback accordingly
        {
            case 1:
            if(pass.equals("9806"))
            {
                resultString += "     ...Huh? It doesn't work. You're sure that you entered" +
                "\n" + "the code that was on the paper. Maybe you should take" +
                "\n" + "another look at it.";
            }
            else if(pass.equals("9086"))
            {
                resultString += "     You enter the password that you think is correct and..." +
                "\n" + "It looks like it's working! The monitor turns green. You had" +
                "\n" + "simply read the slip of paper upside-down at first." + "\n";
                correct1 = true;
            }
            else{
                resultString += "     You tell yourself to stop messing around. You're never" +
                "\n" + "going to just guess the password on your own. You need a" +
                "\n" + "clue to figure this out.";
            }
            break;
            case 2:
            if(pass.equals("RUN"))
            {
                resultString += "     You enter the word you think is correct, and..." +
                "\n" + "Yes! It opened! Inside is a journal. It's most likely" +
                "\n" + "important to your progress.";
                correct2 = true;
            }
            else
            {
                resultString += "     Guessing isn't going to help you guess this" +
                "\n" + "password. If you don't know it, you should probably" +
                "\n" + "look for more clues.";
            }
            break;
            case 3:
            if(pass.equals("Fontaine") || pass.equals("fontaine") || pass.equals("Durand") || pass.equals("durand"))
            {
                correct3 = true;
            }
            else
            {
                endGame = true;
            }
            break;
        }
        return resultString;
    }
    
    public boolean getCorrect(int pheta)
    {
        switch(pheta)
        {
            case 1:
            if(correct1 == true)
            {
                correct1 = false;
                return true;
            }
            else if(correct1 == false)
            {
                return false;
            }
            break;
            case 2:
            if(correct2 == true)
            {
                correct2 = false;
                return true;
            }
            else if(correct2 == false)
            {
                return false;
            }
            break;
            case 3:
            if(correct3 == true)
            {
                correct3 = false;
                return true;
            }
            else if(correct3 == false)
            {
                return false;
            }
            break;
        }
        return false;
    }
    
    public boolean getEndGame()
    {
        return endGame;
    }
    
    public String showCommands()
    {
        return commands.showAll();
    }
}
