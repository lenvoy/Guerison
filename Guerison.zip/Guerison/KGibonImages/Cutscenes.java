import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;

public class Cutscenes
{
    private int riley = 0;
    private int cameron = 0;
    
    public ArrayList intro()
    {
        ArrayList introList = new ArrayList();
        introList.add("\n" + "     How long have you been riding in this van? Your memory" +
        "\n" + "of the past few hours is hazy at best. You woke up at the" +
        "\n" + "same time you do every morning. 6AM, on the dot. Although," +
        "\n" + "you never ate breakfast. You were too nervous about how today" +
        "\n" + "would pan out. Hopefully, if everything goes well, you will" +
        "\n" + "be returning home as a changed person. And certainly changed" +
        "\n" + "for the better.");
        
        introList.add("\n" + "    From your seat in the back, you can feel the van go off" +
        "\n" + "its balance as it veers from the road onto a dirt path. The" +
        "\n" + "vehicle bobs up and down unceremoniously as it drives over" +
        "\n" + "the gravel, causing a low rumbling sound that makes it" +
        "\n" + "impossible for you to think. You resign yourself to simply" +
        "\n" + "relaxing until you reach your destination.");
        
        introList.add("\n" + "     It doesn't take long. Before you know it, the van slows" +
        "\n" + "to a stop. You wonder for a moment if you should open the" +
        "\n" + "door, but before you can do anything it jolts open, and you" +
        "\n" + "get your first look at your current location. You step out" +
        "\n" + "onto the grass and find yourself at the top of a small hill," +
        "\n" + "overlooking what would probably have been a beautiful" +
        "\n" + "landscape many years ago. About thirty meters away, the" +
        "\n" + "rolling hills give way to a ravine with a river winding" +
        "\n" + "through the bottom. Trees dot the hills all around, making" +
        "\n" + "the area seem slightly less barren. Slightly.");
        
        introList.add("\n" + "     In the distance, you can make out the shape of... a" +
        "\n" + "building? It is too dark to see any of the details, but" +
        "\n" + "there seem to be tiny lights that glitter luringly from" +
        "\n" + "across the landscape.");
        
        introList.add("\n" + "     While you are looking around, you don't even notice" +
        "\n" + "the van start up behind you. You turn around just in time" +
        "\n" + "to see it go in reverse back down the hill. Then it swerves" +
        "\n" + "and disappears down the path you came from, leaving you" +
        "\n" + "alone, with not a single other person in sight. You turn" +
        "\n" + "back toward the supposed building. You can tell by which" +
        "\n" + "direction the sun had set that it is almost directly north" +
        "\n" + "of you, about 500 meters away. It wouldn't take very long" +
        "\n" + "to walk to it.");
        
        introList.add("\n" + "What should you do?" +
        "\n" +
        "\n" + "To change your location, type 'go' followed by a direction" +
        "\n" + "such as north, east, south, or west.");
        return introList;
    }
    
    public ArrayList mainGate1()
    {
        ArrayList mainGate1List = new ArrayList();
        mainGate1List.add("     As you make your way closer, you realize that what you" +
        "\n" + "are seeing is definitely not just one building. It looks to" +
        "\n" + "be more on scale with an entire settlement. At least, you" +
        "\n" + "assume that is what lies behind the large wall that seems to" +
        "\n" + "surround the entire area. It looms over you, keeping secret" +
        "\n" + "whatever may lay within. Well, it covers most of what's inside." +
        "\n" + "Stretching into the sky on other side of the wall is what seems" +
        "\n" + "to be a watchtower.");
        
        mainGate1List.add("\n" + "     And even farther behind it is a structure that you can only" +
        "\n" + "see the top of, but its style reminds you of the gothic" +
        "\n" + "castles you've seen in history books. You deside that this" +
        "\n" + "entire location is what you would imagine a citadel to be. A" +
        "\n" + "small ways toward the west, you can see what looks like a" +
        "\n" + "gate. With nothing to loose, you head towards it.");
        
        mainGate1List.add("\n" + "     Before you can even reach the gate, you detect movement" +
        "\n" + "from its direction. One, or maybe two people, are walking in" +
        "\n" + "towards you. For a moment you panic, and consider turning" +
        "\n" + "around, but you decide that would be unwise and simply wait" +
        "\n" + "for them to reach you.");
        
        mainGate1List.add("\n" + "     The first person that reaches you is a boy, about your" +
        "\n" + "age, with light skin and dirty blonde hair. He is tall and" +
        "\n" + "looks as though he is the type of person you wouldn't want" +
        "\n" + "to get in a fight with.");
        
        mainGate1List.add("\n" + "     \"So, you're finally here,\" he says. His voice is gruff but not" +
        "\n" + "quite unfriendly, and you decide that he seems nice enough." +
        "\n" + "But you are rather confused. How did he know you were going" +
        "\n" + "to be here?");
        
        mainGate1List.add("\n" + "     \"Check your tablet,\" he says pointedly, apparently" +
        "\n" + "sensing your confusion. You had almost forgotten about the" +
        "\n" + "device you've been carrying. The driver of your van gave it" +
        "\n" + "to you when you left your house, and told you it was very" +
        "\n" + "important and not to lose it. You haven't bothered" +
        "\n" + "experimenting with it yet, but you suppose that now is as" +
        "\n" + "good a time as any.");
        
        mainGate1List.add("\n" + "Type 'tablet' to check your tablet.");
        return mainGate1List;
    }
    
    public ArrayList tablet()
    {
        ArrayList tabletList = new ArrayList();
        tabletList.add("     You tap the tablet screen and it lights up, shining" +
        "\n" + "brightly in the dark. On it are many white lines and labels." +
        "\n" + "At the bottom are also a group of multi-colored dots, each" +
        "\n" + "with a label. One reads \"Cameron,\" another reads \"Riley,\"" +
        "\n" + "rand the third dot is labeled \"You.\" Of course, you" +
        "\n" + "have no idea what these three dots are meant to signify" +
        "\n" + "You ask the boy what they mean.");
        
        tabletList.add("\n" + "     He snorts. \"Isn't it obvious? It's a map. And the" +
        "\n" + "three dots mark our respective locations. We both have a" +
        "\n" + "tablet just like yours.\" He nods his head in the direction" +
        "\n" + "of the other person who had come with him. Until then, she" +
        "\n" + "had been quiet, making no attempt at conversation. It's" +
        "\n" + "dark, but you can tell that she has darker hair and skin" +
        "\n" + "than Cameron, and seems less personable.");
        
        tabletList.add("\n" + "     \"That's... right,\" she mumbles, raising her tablet" +
        "\n" + "so you can see it. \"We both have ours as well, so we could" +
        "\n" + "tell that there was another person coming...\"");
        
        tabletList.add("\n" + "     Her tablet looks different than yours. It has no" +
        "\n" + "screen, only a large button in the center. You ask her why" +
        "\n" + "that is, and the boy answers for her. \"Well, because if it" +
        "\n" + "had a screen, she wouldn't be able to use it, now would she?\"" +
        "\n" + "He acts as if it was an obvious answer. Sensing that you" +
        "\n" + "still don't understand, he continues. \"She wouldn't be able" +
        "\n" + "to read the screen. She's blind.\"");
        
        tabletList.add("\n" + "     You feel stupid for not realizing it earlier, and" +
        "\n" + "apologize to the girl. She only shuffles uncomfortably, and" +
        "\n" + "says \"It's really no big deal...\"");
        
        tabletList.add("\n" + "     Either way, it makes sense. These two people have" +
        "\n" + "tablets of their own, so it would be obvious just by using" +
        "\n" + "them that a third person would be accompanying them.");
        
        tabletList.add("\n" + "     \"Anyway, as you've probably guessed, I'm Cameron,\"" +
        "\n" + "says the tall boy, pointing at himself with a grin. \"And" +
        "\n" + "this here is Riley.\" Riley seems grateful that he had" +
        "\n" + "introduced her, rather than having to do so herself. You" +
        "\n" + "feel tempted to comment that you hadn't guessed, as both" +
        "\n" + "of their names are notably androgynous, but you think" +
        "\n" + "better of it and say nothing.");
        
        tabletList.add("\n" + "     \"Can we go now?\" Riley asks. She sounds tired," +
        "\n" + "as though she hasn't slept in a long while. You and" +
        "\n" + "Cameron have no reason to argue, so the three of" +
        "\n" + "you head for the gate.");
        
        tabletList.add("\n" + "((At this point, only the Tablet screen and character portraits will be displayed until the ending.))");
        
        tabletList.add("\n" + "     You reach the gate soon enough, and find that it is" +
        "\n" + "much larger than you expected. One huge wooden bar runs" +
        "\n" + "across it, and you think to yourself that it looks almost" +
        "\n" + "impossible to get through as it is.");
        
        tabletList.add("\n" + "     \"So how are we supposed to open this?\" Riley asks." +
        "\n" + "It is clear by her demeanor that she doesn't want to waste" +
        "\n" + "any time. You and Cameron stare at the door for a moment," +
        "\n" + "thoroughly puzzled.");
        
        tabletList.add("\n" + "     \"I think we have to use that thing,\" says Cameron." +
        "\n" + "\"See? There's a monitor over there on the side.\" Sure" +
        "\n" + "enough, there is a small screen on the right hand side of" +
        "\n" + "the wall around the gate. It's dimly lit, but you can still" +
        "\n" + "see the details. There seems to be a password lock on it.");
        
        tabletList.add("\n" + "     \"Well, standing around isn't going to do anything,\"" +
        "\n" + "Riley says with a sigh. \"We have to figure out this" +
        "\n" + "password. Are there any clues around for us to examine?\"" +
        "\n" + "The question strikes you as odd, even though it seems" +
        "\n" + "to be the obvious solution to Riley. Clues... Is there" +
        "\n" + "anything like that around here?");
        
        tabletList.add("\n" + "     You will need to search the area for clues in order to find" +
        "\n" + "the solution you need. The process begins with using the 'look'" +
        "\n" + "command in order to survey your current area, and then use the" +
        "\n" + "'examine' command followed by objects of interest in the room.");
        
        tabletList.add("\n" + "     You will also need to use the 'take' command to retrieve any" +
        "\n" + "items that you find, as well as the 'examine' command followed by" +
        "\n" + "the items that you take. Once you believe you have the solution," +
        "\n" + "you must 'examine' the object that you need to alter in order to" +
        "\n" + "proceed (in this case, the monitor), and input the solution that" +
        "\n" + "you find. Good luck!");
        return tabletList;
    }
    
    public ArrayList unlockGate()
    {
        ArrayList unlockGateList = new ArrayList();
        unlockGateList.add("     As the monitor goes green, you hear the gate rumble behind you" +
        "\n" + "and the bar slides up and out of the way. There's nothing stopping" +
        "\n" + "the three of you from progressing now.");
        
        unlockGateList.add("\n" + "     \"Well, we can open the gate now,\" Riley says flatly. \"Would" +
        "\n" + "you fine persons care to do the honors?\" You roll your eyes, and" +
        "\n" + "Cameron just chuckles. The two of you brace yourselves against the" +
        "\n" + "right door of the gate, and push with all your might. It opens quickly," +
        "\n" + "and before you know it you're in.");
        
        unlockGateList.add("\n" + "     You have to admit, you're pretty impressed by what you see next." +
        "\n" + "You had expected maybe a few small buildings that you would need to" +
        "\n" + "explore, but this is much, much, larger. Behind the huge stone walls" +
        "\n" + "is an entire city! A little ways ahead is a road that veers off to" +
        "\n" + "goodness knows where, and in the distance you can see the outlines of" +
        "\n" + "many large buildings. One of them looks like a church. Another a school" +
        "\n" + "building. And closer to you there is what looks like an entire housing" +
        "\n" + "district. You hope you don't have to search every home.");
        
        unlockGateList.add("\n" + "     Despite all this, the most noticable feature inside the citadel is" +
        "\n" + "a huge castle that looms in the distance. You could make out the top of" +
        "\n" + "it while you were outside the wall, and it is still hard to make out" +
        "\n" + "from your position at the main gate, but nevertheless it is awe" +
        "\n" + "inspiring.");
        
        unlockGateList.add("\n" + "     Your companions have also been admiring their surroundings. It's" +
        "\n" + "Cameron that breaks the silence. \"Did either of you guys know it would" +
        "\n" + "be like this when you signed up?\" You and Riley shake your heads in" +
        "\n" + "unison. \"Yeah, didn't think so.\" He shuffles his feet for a moment" +
        "\n" + "and then lifts his head, looking at you. \"Well, why don't you lead" +
        "\n" + "the way,\" he offers. \"I imagine as long as we head north onto that" +
        "\n" + "road and follow it, we should find something worthwhile.\"");
        
        unlockGateList.add("\n" + "Go north onto the road with Cameron and Riley.");
        return unlockGateList;
    }
    
    public ArrayList plaza()
    {
        ArrayList plazaList = new ArrayList();
        plazaList.add("     As the sign indicated, following the road east brings the three" +
        "\n" + "of you to a large plaza, presumably at the very center of the citadel." +
        "\n" + "The road opens up into the shape of a square, with street lights" +
        "\n" + "lining the area in rows. At the center of the plaza is a medium sized" +
        "\n" + "fountain, but it doesn't look like it's been actively running water" +
        "\n" + "for a long time.");
        
        plazaList.add("\n" + "     Cameron walks ahead of you and Riley, heading straight for the" +
        "\n" + "fountain. Riley seems to notice, and calls after him.");
        
        plazaList.add("\n" + "     \"Hey Cameron, where are you going?\" Cameron doesn't answer" +
        "\n" + "and Riley looks hurt that he would ignore her. He just continues" +
        "\n" + "towards the fountain. Once he reaches it he bends down, seeming to" +
        "\n" + "be inspecting something. Once he's done, he makes his way back to" + 
        "\n" + "where you and Riley have been waiting.");
        
        plazaList.add("\n" + "     \"Hey, check out what I found,\" he says, turning on his feet so" +
        "\n" + "that you and Riley can see. He is wearing a backpack, similar to one" +
        "\n" + "that kids used to bring to school to carry their books. \"This ought" +
        "\n" + "to be helpful with exploring, don'tcha think?\" You and Riley stand" +
        "\n" + "there awkwardly for a moment, then Riley speaks.");
        
        plazaList.add("\n" + "     \"Are... are there any other ones...?\" she asks. You've been" +
        "\n" + "thinking the same thing. It would be an unfair advantage if Cameron" +
        "\n" + "has a backpack to hold his items but you and Riley don't.");
        
        plazaList.add("\n" + "     \"Yup, right over by the fountain,\" he replies. \"Anyway, I" +
        "\n" + "think I'll be going off on my own now.\" Without another word, he" +
        "\n" + "heads off down the road. You think to ask him to stay, but you" +
        "\n" + "realize that at some point, the three of you have to split up. You" +
        "\n" + "are competing, after all.");
        
        plazaList.add("\n" + "     As the two of you make your way towards the fountain, it" +
        "\n" + "becomes apparent that Cameron had lied. Or rather, had bended the" +
        "\n" + "truth. There's only one backpack left resting against the fountain." +
        "\n" + "Not enough for both you and Riley. You relay the information to" +
        "\n" + "her and she sighs, muttering something under her breath.");
        
        plazaList.add("\n" + "     You stand around for a moment, unsure of what to say, then" +
        "\n" + "notice huge building to the north. Or rather, a huge castle to" +
        "\n" + "the north. You mention it to Riley. \"Can we get in?\" she asks. You" +
        "\n" + "squint at the entrance, and respond. There's no way you're about to" +
        "\n" + "get inside that castle, because there's a huge iron gate blocking" +
        "\n" + "the entrance.");
        
        plazaList.add("\n" + "     \"Well, standing around won't help,\" Riley states flatly." +
        "\n" + "\"Are you going to take that backpack or not? If you aren't, I will." +
        "\n" + "I doubt I would be able to reach it before you, but If you don't want" +
        "\n" + "it...\" She let the sentence hang in the air. Will you take the" +
        "\n" + "backpack, and leave Riley without it?");
        
        plazaList.add("\n" + "Will you take the backpack, or leave the area to let Riley have it?");
        
        plazaList.add("\n" + "     At this point, you're on your own. You will nead to" +
        "\n" + "search through all of the citadel to find your way into the castle in" +
        "\n" + "order to reach the end of the test. To do this, there are a few more" +
        "\n" + "commands that you will need to make use of.");
        
        plazaList.add("\n" + "     The first of these new commands is 'equip'. There are many" +
        "\n" + "many reasons to equip an item. Equipping an item and then" +
        "\n" + "examining another item may result in a reaction in the examined" +
        "\n" + "item, if the correct item is equipped. Similarly, examining specific" +
        "\n" + "objects with the correct equip will also produce a reaction.");
        
        plazaList.add("\n" + "     The other reason to use the 'equip' command is when combining" +
        "\n" + "items. There will always be three items that are needed to produce a" +
        "\n" + "single item. To do this, equip the item that would be used to connect" +
        "\n" + "the other two items, and then use the 'combine' command twice," +
        "\n" + "once in conjunction with both of the objects you wish to combine" +
        "\n" + "with your equipped item. As a side note, you may use the 'unequip'" +
        "\n" + "command at any time to unequip your current equipped item, or" +
        "\n" + "re-use the equip command to switch your equipped item.");
        
        plazaList.add("\n" + "     In addition to taking items, you may also 'drop' them. If" +
        "\n" + "you don't take the backpack, your carrying capacity is only five" +
        "\n" + "items. This means that you will definitely need to swap items" +
        "\n" + "in and out of your inventory by dropping them. When you enter an" +
        "\n" + "area that contains an item you previously dropped, you will be" +
        "\n" + "alerted. If you take the backpack, don't worry about it.");
        
        plazaList.add("\n" + "     In case you haven't tried it yet, using 'tablet' outside" +
        "\n" + "of the introduction will give you the locations of your opponents" +
        "\n" + "Speaking of your opponents, you also have the ability to 'talk' to" +
        "\n" + "Riley and Cameron when you see them. However, you may only talk to" +
        "\n" + "them once each for every time you meet. You may need to make use of" +
        "\n" + "your 'tablet' to find them! You can now move freely around the" +
        "\n" + "map. Don't forget to choose whether or not to take the backpack!");
        return plazaList;
    }
    
    public ArrayList secondFloor()
    {
        ArrayList secondFloorList = new ArrayList();
        secondFloorList.add("     With the door to the staircase open, you can now climb the" +
        "\n" + "stairs up to the second floor of the castle. You have a feeling" +
        "\n" + "that this is the last part of the test. There must be one task" +
        "\n" + "left for you to solve. As you're pondering what might lay at the" +
        "\n" + "top of the stairs, you hear voices behind you. You turn around" +
        "\n" + "and as you guessed, it's Riley and Cameron.");
        
        secondFloorList.add("\n" + "     \"Hey, you weren't planning on heading up there without us," +
        "\n" + "were you?\" Cameron asks jokingly. However, there's an edge to his" +
        "\n" + "voice. It wouldn't surprise you if he actually suspected you of" +
        "\n" + "intending to go on ahead without him and Riley.");
        
        secondFloorList.add("\n" + "     \"Well, we can go ahead now,\" says Riley. \"I don't know" +
        "\n" + "about you two, but I can't wait to get out of here.\" It's true." +
        "\n" + "You have long since been worn out from running around the citadel," +
        "\n" + "unlocking doors and combining items. You motion for the door and" +
        "\n" + "ask Riley and Cameron if they're ready. Riley simply nods her" +
        "\n" + "head. Cameron steps forward to playfully shove you out of the way.");
        
        secondFloorList.add("\n" + "     \"Hey, you don't have to ask me twice,\" he says. Then he" +
        "\n" + "opens the door. Inside is a tight spiral staircase, similar to" +
        "\n" + "what would be in an old lighthouse, except made of stone. Cameron" +
        "\n" + "goes in first, then you let Riley go in next, and finally yourself." +
        "\n" + "As you make your way up the stairs, none of the three of you" +
        "\n" + "have any desire to converse. You're all thinking the same thing;" +
        "\n" + "Only one player can win the test and be healed. Who will it be?" +
        "\n" + "You suppose you'll find out soon enough.");
        
        secondFloorList.add("\n" + "     Eventually, the stairs stop, with another closed door at the" +
        "\n" + "end. It's unlocked, and Cameron opens it without hesitation." +
        "\n" + "You and Riley emerge through the door soon after him, and are" +
        "\n" + "greeted with a very unusual sight.");
        
        secondFloorList.add("\n" + "     The room you find yourself in is completely undecorated. If" +
        "\n" + "you didn't know any better, you'd say it looks like one of those" +
        "\n" + "completely white rooms like in the old cartoons you used to watch" +
        "\n" + "when you were a kid. Anyway, the only interesting thing, or things," +
        "\n" + "about this room are the three doors situated at the southern wall." +
        "\n" + "They are all identical white doors, except that each of them is" +
        "\n" + "labeled differently.");
        
        secondFloorList.add("\n" + "     \"Hey, the labels on those doors...\" Cameron's voice trails" +
        "\n" + "off as he steps forward. On each door is a name. Specifically," +
        "\n" + "the first names of you and your companions. Could this mean that" +
        "\n" + "the test is over, and all three of you have won and need only" +
        "\n" + "enter through your respective doors to claim your prize?");
        
        secondFloorList.add("\n" + "     Riley coughs abruptly. \"Either of you two care to fill" +
        "\n" + "me in?\" Her voice is sharp, as if she is offended that neither" +
        "\n" + "you nor Cameron thought to inform her of what is going on. You" +
        "\n" + "quickly explain to her that there are three doors with your names" +
        "\n" + "on them. \"Well, are they locked?\" she asks impatiently. \"We" +
        "\n" + "could be looking at the end of all this right now!\"");
        
        secondFloorList.add("\n" + "     \"Here, lemme check,\" Cameron says as he reaches for his" +
        "\n" + "own door, on the right. He turns the knob and pulls, and the door" +
        "\n" + "slides easily open. \"Yup, we can go in.\" You ask Cameron what's" +
        "\n" + "inside the door. \"Well, it looks like there are two other doors" +
        "\n" + "in there. One of them has a monitor on it, just like the one back" +
        "\n" + "at the main gate way back when. And the other door says 'Exit.'\"");
        
        secondFloorList.add("\n" + "     \"It's probably for after you've gone into the first door," +
        "\n" + "Riley chimes in. \"I'm guessing the door with the monitor on it" +
        "\n" + "is locked?\" Cameron steps in and tugs on the door. It doesn't" +
        "\n" + "budge.");
        
        secondFloorList.add("\n" + "     Suddenly, an electronic voice sounds from the monitor in" +
        "\n" + "Cameron's room. \"Participant detected. Locking entry door.\"" +
        "\n" + "Before anyone knows what is going on, the door leading into" +
        "\n" + "Cameron's room slams shut. Riley runs over to pull at it, but" +
        "\n" + "it's locked tight. She yells to Cameron, but either he can't" +
        "\n" + "hear her or you and Riley can't hear him. The doors must be" +
        "\n" + "sound-proof. You ask Riley what she thinks you should do.");
        
        secondFloorList.add("\n" + "     \"The only thing we can do, obviously. We've got to go" +
        "\n" + "into our own doors!\" When you think about it, Riley is probably" +
        "\n" + "right. You're not helping Cameron by just sitting around doing" +
        "\n" + "nothing. Besides, he's probably doing fine. Maybe he's even won" +
        "\n" + "the competition already! You tell Riley that you agree with her," +
        "\n" + "and she nods. \"Alright, let's go.\"");
        
        secondFloorList.add("\n" + "     You and Riley both head for your own doors. Hers is on the" +
        "\n" + "left, and yours is in the center, between hers and Cameron's." +
        "\n" + "Without another word, you both step in and wait for the electronic" +
        "\n" + "voice to announce the closing of the entrance. It does, and you" +
        "\n" + "find yourself shut in. To your left is the exit door. It probably" +
        "\n" + "leads to somewhere outside of the castle. You direct your attention" +
        "\n" + "to the monitor.");
        
        secondFloorList.add("\n" + "It appears that a set of instructions appeared on the screen. They" +
        "\n" + "read as follows: \"This password is authenticated by your voice." +
        "\n" + "When you know the solution, simply say it.\" Simple enough. Moving" +
        "\n" + "on, it reads \"There are two acceptable passwords to say. They are" +
        "\n" + "the last names of your two opponents in this contest. Please say" +
        "\n" + "one of these two names at this point. If your guess is incorrect" +
        "\n" + "this monitor will shut down and you must take the exit to your" +
        "\n" + "left. In contrast, a correct response will result in your success" +
        "\n" + "in the Guerison Project.\"");
        
        secondFloorList.add("\n" + "     The last names of your two opponents? So in other words," +
        "\n" + "if you know the last name of either Cameron or Riley, you'll" +
        "\n" + "be able to advance. If not... Well, you don't want to think" +
        "\n" + "about it. Anyway, it's now or never. You ready yourself to" +
        "\n" + "speak the password as clearly as possible.");
        return secondFloorList;
    }
    
    public ArrayList goodEnd()
    {
        ArrayList goodEndList = new ArrayList();
        goodEndList.add("\n" + "     The screen on the monitor changes colors to green. You hear a" +
        "\n" + "clicking sound which is probably the door unlocking. Before you" +
        "\n" + "enter, the electronic voice comes back on. \"Congratulations, you" +
        "\n" + "have succeeded. Thank you for your participation.\"");
        
        goodEndList.add("\n" + "     You pull the door open, and find yourself outside, high up" +
        "\n" + "in the air. It takes you a few moments to realize that you are" +
        "\n" + "on a balcony which overlooks the entire area, giving a beautiful" +
        "\n" + "view of the citadel. At the center of the balcony is some sort of" +
        "\n" + "sign. Standing right beside it is none other than Cameron.");
        
        goodEndList.add("\n" + "     \"Hey, you made it!\" he exclaims. \"Come over here and look" +
        "\n" + "at this!\" Just before you can comply, you hear a noise from behind" +
        "\n" + "You spin around to see Riley bursting out of one of the doors." +
        "\n" + "You and Cameron call to her, and she looks relieved to hear" +
        "\n" + "both of your voices.");
        
        goodEndList.add("\n" + "     \"We did it,\" she says nervously, concentrating rather than" +
        "\n" + "being excited. \"So, where is it?! Where's the supposed cure?\"" +
        "\n" + "You had nearly forgotten. You look expectantly at Cameron, who" +
        "\n" + "has had the most time to look around.");
        
        goodEndList.add("\n" + "     \"You're never going to believe it,\" he says, beaming." +
        "\n" + "\"This sign here explains everything. Apparently there is no" +
        "\n" + "'cure' in the sense of just one object.\" He paused, as if for" +
        "\n" + "dramatic effect. \"The reality is, everything in this citadel" +
        "\n" + "is the cure!\"");
        
        goodEndList.add("\n" + "     Riley looks confused. \"That doesn't make any sense. What" +
        "\n" + "is that supposed to mean?\"");
        
        goodEndList.add("\n" + "     Cameron continues his explanation. \"I read about it in the" +
        "\n" + "library. This citadel used to serve as a station for wounded troops" +
        "\n" + "during the last World War. It was then that they began to realize" +
        "\n" + "that the area possessed strange, almost supernatural properties." +
        "\n" + "People would never get sick, and the soldiers would be healed of" +
        "\n" + "their injuries within hours of visiting the citadel.\"");
        
        goodEndList.add("\n" + "     \"Five years ago, a group of researchers interested in the" +
        "\n" + "area rediscovered it's healing properties and decided to conduct" +
        "\n" + "a series of tests to see if the legend is true.\"");
        
        goodEndList.add("\n" + "     Riley interrupts him for a moment to ask a question. \"And these" +
        "\n" + "tests you mentioned... They were just like this competition?\"");
        
        goodEndList.add("\n" + "     Cameron nods vigorously. \"And not  just 'like'... 'are'! This" +
        "\n" + "experiment that we applied for and participated in, was one" +
        "\n" + "of the very first ever conducted!\"");
        
        goodEndList.add("\n" + "     If Riley had her eyes open, they would show nothing but" +
        "\n" + "distress and panic. \"But my brother...\"");
        
        goodEndList.add("\n" + "     Cameron shakes his head. \"Don't worry, there's another" +
        "\n" + "perk to this whole system. Apparently the healing properties" +
        "\n" + "come directly from the structure of the citadel. All you need" +
        "\n" + "is a chipped piece of the stone, or a small tile, and no matter" +
        "\n" + "where you take it, it'll do the trick!");
        
        goodEndList.add("\n" + "     There are tears spilling down Riley's face. \"Then my" +
        "\n" + "brother... He's going to be ok...\" She has to take a moment to" +
        "\n" + "compose herself. Even Cameron seems to be having trouble" +
        "\n" + "holding his excitement back. You don't feel the need to" +
        "\n" + "cry like Riley, but you feel as though a wave of relief" + 
        "\n" + "has washed over you. You haven't felt this liberated in" +
        "\n" + "years, at least. You have the feeling that things are" +
        "\n" + "finally starting to look up for you...");
        
        goodEndList.add("\n" + "     . . .");
        
        goodEndList.add("\n" + "     . . .");
        
        goodEndList.add("\n" + "     ~*~   End");
        return goodEndList;
    }
    
    public ArrayList badEnd()
    {
        ArrayList badEndList = new ArrayList();
        badEndList.add("\n" + "     The screen on the monitor fades to black. Your heart lurches" +
        "\n" + "as you watch helplessly, and for a moment you wonder if any of this" +
        "\n" + "is even real. Why would they ask you about someone's last name?" +
        "\n" + "What does that accomplish?! You can sense your temper rising to a" +
        "\n" + "fever pitch. You try to calm yourself down, but it's no good.");
        
        badEndList.add("\n" + "     Fuming, you open the exit door and storm through it. You don't" +
        "\n" + "even care what happens to you anymore. You punch the wall as you" +
        "\n" + "walk. You can see your knuckles begin to bleed, but what does it" +
        "\n" + "matter? This entire trip was a complete and utter waste of time." +
        "\n" + "Your only hope is that Riley and Cameron didn't fail themselves" +
        "\n" + "as you did.");
        
        badEndList.add("\n" + "     . . .");
        
        badEndList.add("\n" + "     . . .");
        
        badEndList.add("\n" + "     \\/\\   Game Over");
        return badEndList;
    }
    
    public ArrayList talkRiley()
    {
        ArrayList talkRileyList = new ArrayList();
        switch(riley)
        {
            case 0:
            talkRileyList.add("\n" + "     " + "Eager to start up a conversation, you ask Riley about" +
                    "\n" + "the first thing that comes to your mind, which is what her" +
                    "\n" + "family is like. For a moment you swear you can see her" + 
                    "\n" + "cringe, but you are probably just imagining it.");
            talkRileyList.add("\n" + "     " + "\"Well, my parents are very nice, if that's what you" +
                    "\n" + "mean... What about you? What's your family like?\"");
            talkRileyList.add("\n" + "     " + "The question has you taken aback. You haven't even" +
                    "\n" + "thought about your family today. All that you can think" +
                    "\n" + "about is the competition. You imagine that Riley and" +
                    "\n" + "Cameron must be feeling the same way. It looks like Riley" +
                    "\n" + "isn't in the mood to talk anymore.");
            break;
            case 1:
            talkRileyList.add("\n" + "     " + "Riley seems slightly more receptive to conversation" +
                    "\n" + "this time. You ask her how her search is going.");
            talkRileyList.add("\n" + "     " + "\"You're kidding, right?\" she says, chuckling slightly." +
                    "\n" + "\"I'm not exactly well suited for this kind of work, but I" +
                    "\n" + "have to admit, whoever set up this test was pretty considerate." +
                    "\n" + "Most of the signs and books have braille written on them," +
                    "\n" + "so I'm able to hold my own for the most part.\"");
            talkRileyList.add("\n" + "     " + "You're not entirely sure where to take the conversation" +
                    "\n" + "from there, so you ask Riley what it's like to be blind," +
                    "\n" + "hoping the question isn't too intrusive.");
            talkRileyList.add("\n" + "     " + "Riley sighs slightly, as though she's had to answer this" +
                    "\n" + "question many times before. \"You get used to it I suppose,\"" +
                    "\n" + "she responds dully. \"To be perfectly honest, I don't think\"" +
                    "\n" + "I'd want to see even if I could. I get the feeling it would be" +
                    "\n" + "pretty overwhelming.\"");
            talkRileyList.add("\n" + "     " + "What Riley said made sense, but you are genuinely confused." +
                    "\n" + "If she doesn't want to see, then why was she here, participating" +
                    "\n" + "in this test? You're about to ask her, but the look on her face" +
                    "\n" + "gives you the impression that she's done with answering your" +
                    "\n" + "questions. It's probably best to leave her alone.");
            break;
            case 2:
            talkRileyList.add("\n" + "     " + "You take the opportunity to ask Riley the question that's" +
                    "\n" + "beem on your mind since your last conversation. Why did she" +
                    "\n" + "apply to be healed if she doesn't want to see?");
            talkRileyList.add("\n" + "     " + "\"It's not obvious already?\" she says with faked shock." +
                    "\n" + "\"I'm not here for myself. I'm here for my brother.\" The" +
                    "\n" + "realization of what that means hits you like a brick. You had" +
                    "\n" + "thought of Riley as an opponent, just another person that wants" +
                    "\n" + "to heal herself. You never would have imagined that anyone could" +
                    "\n" + "be so selfless. You stammer, at a loss for words.");
            talkRileyList.add("\n" + "     " + "\"That's exactly why I didn't say anything at first,\" she" +
                    "\n" + "says. \" I didn't want you and Cameron to think I'm a show off.\"" +
                    "\n" + "She stares into the distance, her face torn. \"You don't think" +
                    "\n" + "I'm showing off, do you?\" You tell her no, of course not. A" +
                    "\n" + "small smile forms across her lips. \"Thank you...\"");
            talkRileyList.add("\n" + "     " + "Unsure of what else to say, you tell Riley goodbye.");
            break;
            case 3:
            talkRileyList.add("\n" + "     " + "This time, it's Riley that starts the conversation." +
                    "\n" + "\"Hey, I wanted to ask you something...\" she begins. \"What's" +
                    "\n" + "your last name?\" You ask Riley why that's important. She pouts" +
                    "\n" + "and puts her hands on her hips, leaning forward.");
            talkRileyList.add("\n" + "     " + "\"Because I want to keep in touch, obviously! Who knows if\"" +
                    "\n" + "we'd ever meet up again somewhere by chance. And it's not like" +
                    "\n" + "I would recognize you.\" She has a point. You decide to give her" +
                    "\n" + "your last name.");
            talkRileyList.add("\n" + "     " + "\"Great! I'll look you up sometime. Oh! I almost forgot,\"" +
                    "\n" + "she says. \"It'd be rude of me not to tell you my full name as" +
                    "\n" + "well. It's 'Fontaine.' Write it down somewhere so you don't" + 
                    "\n" + "forget it!\"");
            talkRileyList.add("\n" + "     " + "You thank Riley for the information and tell her goodbye." +
                    "\n" + "You feel as though even in a situation like this, you've made" +
                    "\n" + "a good friend.");
            break;
            default:
            talkRileyList.add("\n" + "     " + "You and Riley have already talked a lot during your time" +
                    "\n" + "together in the citadel.");
            talkRileyList.add("\n" + "You probably shouldnt spend any more time chatting.");
        }
        riley++;
        return talkRileyList;
    }
    
    public ArrayList talkCameron()
    {
        ArrayList talkCameronList = new ArrayList();
        switch(cameron)
        {
            case 0:
            talkCameronList.add("\n" + "     " + "To be honest, you're rather intimidated by Cameron. But" +
                    "\n" + "you decide to try and talk to him and be friendly anyway. You" +
                    "\n" + "get his attention and ask him what's up.");
            talkCameronList.add("\n" + "     " + "\"Oh, that's rich,\" he says, laughing. It sounds forced" +
                    "\n" + "and it makes you uncomfortable. \"What, are you trying to see" +
                    "\n" + "what kind of progress I'm making? Make sure I'm not doing better" +
                    "\n" + "than you?\" His voice is rising rapidly. You try to tell him" +
                    "\n" + "That you only wanted to chat. He seems to cool down a bit.");
            talkCameronList.add("\n" + "     " + "\"Save it. I'm not telling you anything. If you actually" +
                    "\n" + "need something, you can ask, but I'm not in the mood to talk.\"");
            talkCameronList.add("\n" + "     " + "At that, Cameron turns his back on you and goes about his" +
                    "\n" + "own business exploring. That probably could have gone better." +
                    "\n" + "Maybe he'll be less abrasive the next time you see him.");
            break;
            case 1:
            talkCameronList.add("\n" + "     " + "Cameron sees you approach, and walks over to meet you." +
                    "\n" + "\"Hey man, sorry I was so rough earlier. Just stressed out I" +
                    "\n" + "guess...\" He doesn't seem very accustomed to apologizing," +
                    "\n" + "and you don't want to make the situation any more awkward, so" +
                    "\n" + "you just tell him it's no big deal.");
            talkCameronList.add("\n" + "     " + "\"So, uh, what are you here for?\" he asks. \"Y'know," +
                    "\n" + "if you're willing to say.\" It's pretty obvious that he's" +
                    "\n" + "trying to change the subject, but you don't mind. You have" +
                    "\n" + "no reason to hide your disability, so you tell him about" +
                    "\n" + "how you've suffered from arrhythmia for the past  5 years.");
            talkCameronList.add("\n" + "     " + "Cameron looks as though he's trying not to scoff at you." +
                    "\n" + "\"That's it? Just some heart palpitations here and there?\"" +
                    "\n" + "Indignant, you ask him what his problem is that's so much" +
                    "\n" + "more important. He ignores you and walks off, muttering to" +
                    "\n" + "himself. \"Both of them, completely selfish...\"");
            break;
            case 2:
            talkCameronList.add("\n" + "     " + "You're a little wary of talking to Cameron considering" +
                    "\n" + "how the last two conversations went. Still, you think you" +
                    "\n" + "might as well try to smooth things over. You walk over to" +
                    "\n" + "him and make small talk at first, then he suddenly changes" +
                    "\n" + "the subject.");
            talkCameronList.add("\n" + "     " + "\"You wanna know why I'm here?\" he asks. You have a" +
                    "\n" + "feeling he would be offended if you say no, so you just nod.");
            talkCameronList.add("\n" + "     " + "\"ALS. Just got diagnosed last month. Scared the shit" +
                    "\n" + "outta me, y'know?\" You feel as though your foot is shoved" +
                    "\n" + "all the way down your throat. You never would have been so" +
                    "\n" + "mean before if you had known the seriousness of his condition.");
            talkCameronList.add("\n" + "     " + "Cameron seems to guess your line of thinking. \"Hey, don't" +
                    "\n" + "worry about it. I know you didn't mean anything by it..." +
                    "\n" + "I'm just kinda on edge because I feel like, well, this is" +
                    "\n" + "my only chance! If I don't win this thing I'm fucked!\" He" +
                    "\n" + "threw his arms up in the air to emphasize his point.");
            talkCameronList.add("\n" + "     " + "\"Anyway, I'm not asking for your sympathy. Heck, I know" +
                    "\n" + "for a fact that a few months ago, if I was in your shoes," +
                    "\n" + "I wouldn't have any. That's not the kinda person I was. I" +
                    "\n" + "guess I just... needed to get that off my chest.\"");
            talkCameronList.add("\n" + "     " + "You're at a loss for words for how to respond. All you" +
                    "\n" + "can manage is a small apology, and then you say goodye.");
            break;
            case 3:
            talkCameronList.add("\n" + "     " + "You would feel bad if you didn't talk to Cameron again" +
                    "\n" + "after what he said last time, so you try to start up a" +
                    "\n" + "conversation. You chat for a while, then Cameron changes the" +
                    "\n" + "subject again.");
            talkCameronList.add("\n" + "     " + "\"Thanks for letting me vent back there man, I really" +
                    "\n" + "needed that.\" You tell him it was no problem. \"By the way," +
                    "\n" + "it seems weird that we know so much about eachother but we" +
                    "\n" + "only know our first names. What's yours?\"");
            talkCameronList.add("\n" + "     " + "You tell Cameron your full name. He nods, as if taking" +
                    "\n" + "in the information. \"Alright. And just so we're square, my" +
                    "\n" + "last name is 'Durand.' Don't forget it, 'cause I'm not" +
                    "\n" + "telling you again!\" At that, he walks off.");
            break;
            default:
            talkCameronList.add("\n" + "     " + "You feel that you've talked to Cameron enough that you" +
                    "\n" + "can consider him a friend. ");
            talkCameronList.add("\n" + "     " + "You should probably focus on completing the test at" +
                    "\n" + "this point.");
        }
        cameron++;
        return talkCameronList;
    }
    
    public void enter()
    {
        String inputLine = "";
        BufferedReader reader = 
            new BufferedReader(new InputStreamReader(System.in));
        try{
            inputLine = reader.readLine();
        }
        catch(java.io.IOException exc){
        }
    }
}
